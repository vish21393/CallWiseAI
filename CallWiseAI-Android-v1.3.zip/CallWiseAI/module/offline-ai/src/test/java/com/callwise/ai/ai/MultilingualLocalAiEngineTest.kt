package com.callwise.ai.ai

import com.callwise.ai.domain.model.CallerCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MultilingualLocalAiEngineTest {

    private val engine = MultilingualLocalAiEngine()

    @Test
    fun `returns null for blank text`() {
        assertNull(engine.analyzeText("   ", AiLanguage.AUTO))
    }

    @Test
    fun `extracts commitments deadlines and intent from English transcript`() {
        val text = """
            Hi, this is Priya from Acme Talent regarding your Android Engineer interview.
            Please send your updated resume by tomorrow 5 pm.
            I will share the meeting link on Friday.
        """.trimIndent()

        val result = engine.analyzeText(text, AiLanguage.AUTO)
        assertNotNull(result)
        assertEquals(AiLanguage.ENGLISH, result?.detectedLanguage)
        assertEquals(CallerCategory.PROFESSIONAL_RECRUITER, result?.detectedCategoryHint)
        assertTrue(result?.commitments?.isNotEmpty() == true)
        assertTrue(result?.datesAndDeadlines?.contains("tomorrow") == true)
    }

    @Test
    fun `detects Hindi and Telugu scripts offline`() {
        val hindi = engine.analyzeText("कल बैंक केवाईसी डॉक्यूमेंट भेजना है।", AiLanguage.AUTO)
        val telugu = engine.analyzeText("రేపు బ్యాంక్ పత్రాలు పంపించు.", AiLanguage.AUTO)

        assertEquals(AiLanguage.HINDI, hindi?.detectedLanguage)
        assertEquals(AiLanguage.TELUGU, telugu?.detectedLanguage)
    }
}

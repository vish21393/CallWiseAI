package com.callwise.ai.ai

import android.os.Debug

data class ModelRecommendation(
    val name: String,
    val role: String,
    val quantization: String,
    val diskSizeGb: String,
    val expectedRamGb: String,
    val languageSupport: String,
    val notes: String
)

data class BenchmarkResult(
    val timestampMillis: Long,
    val engineLabel: String,
    val modelInspectTimeMs: Long,
    val inferenceLatencyMs: Long,
    val nativeHeapMb: Long,
    val jvmHeapUsedMb: Long,
    val sampleSummaryCount: Int,
    val sampleActionCount: Int
)

object ModelCatalogAndBenchmarks {

    /**
     * Curated offline models suited for Vivo X100 Pro (16 GB RAM, 512 GB UFS 4.0, Dimensity 9300).
     * These are reference specifications for optional user-imported local models.
     */
    val vivoX100ProCatalog: List<ModelRecommendation> = listOf(
        ModelRecommendation(
            name = "Qwen 2.5 3B Instruct",
            role = "LLM (Summarisation & VoIP Dialogue)",
            quantization = "Q4_K_M (4-bit)",
            diskSizeGb = "~2.0 GB",
            expectedRamGb = "~2.6 GB",
            languageSupport = "Strong English & Hindi; basic Telugu",
            notes = "Best balance of reasoning, action-item extraction, and thermal stability on Dimensity 9300."
        ),
        ModelRecommendation(
            name = "Gemma 2 2B IT",
            role = "LLM (Fast Dialogue & Intent)",
            quantization = "INT4 (MediaPipe .task)",
            diskSizeGb = "~1.4 GB",
            expectedRamGb = "~1.9 GB",
            languageSupport = "Strong English; moderate Hindi & Telugu",
            notes = "Lowest latency for VoIP conversational turn-taking and barge-in."
        ),
        ModelRecommendation(
            name = "Llama 3.2 3B Instruct",
            role = "LLM (Structured Extraction)",
            quantization = "Q4_K_M (4-bit)",
            diskSizeGb = "~2.0 GB",
            expectedRamGb = "~2.5 GB",
            languageSupport = "Strong English & Hindi; limited Telugu",
            notes = "Reliable JSON/deadline extraction from call notes."
        ),
        ModelRecommendation(
            name = "Whisper Small / Sherpa-ONNX",
            role = "Speech-to-Text (VoIP & Recordings)",
            quantization = "Q5_1 / INT8",
            diskSizeGb = "~0.25 GB",
            expectedRamGb = "~0.5 GB",
            languageSupport = "English, Hindi, and Telugu supported",
            notes = "Good multi-accent Indian English, Hindi, and Telugu recognition offline."
        ),
        ModelRecommendation(
            name = "Piper / Android Offline Neural TTS",
            role = "Text-to-Speech (VoIP Replies)",
            quantization = "ONNX / System Offline",
            diskSizeGb = "~0.06 GB per voice",
            expectedRamGb = "~0.15 GB",
            languageSupport = "English (IN), Hindi, Telugu voices",
            notes = "Near-zero battery and thermal impact; supports instant stop() for barge-in."
        )
    )

    fun runLiveDeviceBenchmark(
        engine: LocalAiEngine,
        modelPath: String
    ): BenchmarkResult {
        val inspectStart = System.nanoTime()
        engine.inspectModelFile(modelPath)
        val inspectMs = ((System.nanoTime() - inspectStart) / 1_000_000L).coerceAtLeast(1L)

        val sampleTranscript = """
            Hi, this is Ananya from HDFC Bank regarding your policy renewal and KYC verification.
            Please send the updated address proof by tomorrow 5 PM.
            I will share the confirmation email once documents are verified.
        """.trimIndent()

        val output = engine.analyzeText(sampleTranscript, AiLanguage.AUTO)
        val runtime = Runtime.getRuntime()
        val jvmUsedMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L)
        val nativeHeapMb = Debug.getNativeHeapAllocatedSize() / (1024L * 1024L)

        return BenchmarkResult(
            timestampMillis = System.currentTimeMillis(),
            engineLabel = output?.engineUsed ?: "Built-in Engine",
            modelInspectTimeMs = inspectMs,
            inferenceLatencyMs = output?.latencyMs ?: 1L,
            nativeHeapMb = nativeHeapMb,
            jvmHeapUsedMb = jvmUsedMb,
            sampleSummaryCount = output?.summaryBullets?.size ?: 0,
            sampleActionCount = output?.actionItems?.size ?: 0
        )
    }
}

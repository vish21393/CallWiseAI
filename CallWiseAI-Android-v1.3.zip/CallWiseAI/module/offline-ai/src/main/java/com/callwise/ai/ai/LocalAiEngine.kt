package com.callwise.ai.ai

import com.callwise.ai.domain.model.CallerCategory
import java.io.File

enum class AiLanguage(val displayName: String) {
    AUTO("Auto (EN / HI / TE)"),
    ENGLISH("English"),
    HINDI("Hindi (हिन्दी)"),
    TELUGU("Telugu (తెలుగు)")
}

data class CallIntelligenceOutput(
    val summaryBullets: List<String>,
    val commitments: List<String>,
    val datesAndDeadlines: List<String>,
    val actionItems: List<String>,
    val detectedCategoryHint: CallerCategory?,
    val detectedLanguage: AiLanguage,
    val latencyMs: Long,
    val engineUsed: String
)

data class LocalModelStatus(
    val modelPath: String,
    val isModelFilePresent: Boolean,
    val fileSizeMb: Long,
    val statusMessage: String
)

interface LocalAiEngine {
    fun inspectModelFile(path: String): LocalModelStatus
    fun analyzeText(text: String, preferredLanguage: AiLanguage = AiLanguage.AUTO): CallIntelligenceOutput?
    fun generateVoipReply(
        callerUtterance: String,
        callerName: String?,
        turnCount: Int,
        preferredLanguage: AiLanguage = AiLanguage.ENGLISH
    ): Pair<String, CallerCategory?>
}

/**
 * 100% offline multilingual intelligence engine supporting English, Hindi, and Telugu.
 * Never invents call transcripts or summaries when actual text/transcript data is unavailable.
 */
class MultilingualLocalAiEngine(
    private val modelPathProvider: () -> String = { "" }
) : LocalAiEngine {

    private val actionKeywords = listOf(
        // English
        "call back", "callback", "send", "share", "email", "follow up", "followup",
        "submit", "verify", "confirm", "documents", "kyc", "pay", "payment", "schedule", "meeting",
        // Hindi / Hinglish
        "भेज", "कॉल", "पेमेंट", "जमा", "वेरिफाई", "bhej", "bhejna", "kal", "call karna", "milna",
        // Telugu / Tenglish
        "పంపు", "పంపించు", "కాల్", "చెల్లించు", "pampu", "pampinchu", "call chey", "repu"
    )

    private val commitmentKeywords = listOf(
        "i will", "i'll", "we will", "we'll", "promised", "committed", "agreed",
        "करूंगा", "दूंगा", "करेंगे", "karunga", "dunga",
        "చేస్తాను", "పంపిస్తాను", "chestanu", "pampistanu"
    )

    private val deadlineRegex = Regex(
        """\b(today|tomorrow|tonight|monday|tuesday|wednesday|thursday|friday|saturday|sunday|""" +
            """\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?|\d{1,2}(?::\d{2})?\s?(?:am|pm)|""" +
            """kal|parso|repu|ellundi)\b""",
        RegexOption.IGNORE_CASE
    )

    override fun inspectModelFile(path: String): LocalModelStatus {
        val trimmed = path.trim()
        if (trimmed.isEmpty()) {
            return LocalModelStatus(
                modelPath = "",
                isModelFilePresent = false,
                fileSizeMb = 0L,
                statusMessage = "No external GGUF/Task model imported. Built-in multilingual heuristic engine is active (0 MB extra RAM)."
            )
        }
        val file = File(trimmed)
        return if (file.exists() && file.isFile) {
            val sizeMb = file.length() / (1024L * 1024L)
            LocalModelStatus(
                modelPath = trimmed,
                isModelFilePresent = true,
                fileSizeMb = sizeMb,
                statusMessage = "Local model file verified (${sizeMb} MB). Ready for native LLM runtime binding; built-in engine active as fallback."
            )
        } else {
            LocalModelStatus(
                modelPath = trimmed,
                isModelFilePresent = false,
                fileSizeMb = 0L,
                statusMessage = "File not found at path. Built-in multilingual engine remains active."
            )
        }
    }

    override fun analyzeText(
        text: String,
        preferredLanguage: AiLanguage
    ): CallIntelligenceOutput? {
        val startNs = System.nanoTime()
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return null

        val detectedLang = if (preferredLanguage == AiLanguage.AUTO) {
            detectLanguage(cleaned)
        } else {
            preferredLanguage
        }

        val sentences = cleaned
            .split(Regex("(?<=[.!?।\\n])\\s+"))
            .map { it.trim() }
            .filter { it.length >= 6 }
            .ifEmpty { listOf(cleaned) }

        val actionItems = sentences.filter { s ->
            val lower = s.lowercase()
            actionKeywords.any { lower.contains(it) }
        }.distinct().take(5)

        val commitments = sentences.filter { s ->
            val lower = s.lowercase()
            commitmentKeywords.any { lower.contains(it) }
        }.distinct().take(4)

        val datesAndDeadlines = deadlineRegex.findAll(cleaned)
            .map { it.value }
            .distinct()
            .take(6)
            .toList()

        val summaryBullets = sentences
            .filterNot { it in actionItems }
            .take(3)
            .ifEmpty { sentences.take(3) }

        val categoryHint = detectCategoryHint(cleaned)
        val latencyMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)

        val modelPath = modelPathProvider().trim()
        val engineLabel = if (modelPath.isNotEmpty() && File(modelPath).exists()) {
            "Local Multilingual Engine (Model Linked)"
        } else {
            "Built-in Multilingual Heuristic Engine (EN/HI/TE)"
        }

        return CallIntelligenceOutput(
            summaryBullets = summaryBullets,
            commitments = commitments,
            datesAndDeadlines = datesAndDeadlines,
            actionItems = actionItems,
            detectedCategoryHint = categoryHint,
            detectedLanguage = detectedLang,
            latencyMs = latencyMs,
            engineUsed = engineLabel
        )
    }

    override fun generateVoipReply(
        callerUtterance: String,
        callerName: String?,
        turnCount: Int,
        preferredLanguage: AiLanguage
    ): Pair<String, CallerCategory?> {
        val lower = callerUtterance.lowercase()
        val category = detectCategoryHint(callerUtterance)
        val namePrefix = callerName?.takeIf { it.isNotBlank() }?.let { "$it, " }.orEmpty()

        val reply = when {
            turnCount == 0 -> {
                "Hello ${namePrefix}this is CallWise AI assistant. May I ask the reason for your call?"
            }
            category == CallerCategory.PROMO_LOAN || category == CallerCategory.CREDIT_CARD_PROMO ||
                category == CallerCategory.REAL_ESTATE_PROMO || category == CallerCategory.NEW_INSURANCE_SALES -> {
                "Thank you for sharing. I've noted this as a promotional call. The user is not taking sales offers right now, goodbye."
            }
            category == CallerCategory.BANK_FINANCIAL || category == CallerCategory.INSURANCE_SERVICING -> {
                "Got it. I've flagged this as an important ${category.displayName} matter. Could you share any reference number or deadline?"
            }
            category == CallerCategory.PROFESSIONAL_RECRUITER -> {
                "Thanks for reaching out about a role. Please state the company name and callback number, and I will notify the user."
            }
            lower.contains("urgent") || lower.contains("emergency") || lower.contains("important") -> {
                "Understood, I am marking this call as urgent and notifying the user to take over now."
            }
            else -> {
                "Thank you. I have recorded your message in the local transcript. Is there a specific callback time or action item?"
            }
        }

        return reply to category
    }

    private fun detectLanguage(text: String): AiLanguage {
        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        if (hasDevanagari) return AiLanguage.HINDI
        val hasTelugu = text.any { it in '\u0C00'..'\u0C7F' }
        if (hasTelugu) return AiLanguage.TELUGU
        return AiLanguage.ENGLISH
    }

    private fun detectCategoryHint(text: String): CallerCategory? {
        val lower = text.lowercase()
        return when {
            lower.contains("interview") || lower.contains("recruiter") || lower.contains("hiring") ||
                lower.contains("इंटरव्यू") || lower.contains("ఇంటర్వ్యూ") ->
                CallerCategory.PROFESSIONAL_RECRUITER
            lower.contains("bank") || lower.contains("account") || lower.contains("kyc") ||
                lower.contains("बैंक") || lower.contains("బ్యాంక్") ->
                CallerCategory.BANK_FINANCIAL
            lower.contains("claim") || lower.contains("renewal") || lower.contains("policy") ->
                CallerCategory.INSURANCE_SERVICING
            lower.contains("loan") || lower.contains("लोन") || lower.contains("లోన్") ->
                CallerCategory.PROMO_LOAN
            lower.contains("credit card") ->
                CallerCategory.CREDIT_CARD_PROMO
            lower.contains("real estate") || lower.contains("property") || lower.contains("plot") ->
                CallerCategory.REAL_ESTATE_PROMO
            else -> null
        }
    }
}

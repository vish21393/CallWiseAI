package com.callwise.ai.voip

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sqrt

/**
 * Owns the VoIP-only TextToSpeech + AudioRecord barge-in pipeline.
 * Never touches cellular SIM audio.
 */
class VoipVoicePipeline(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onSpeakingChanged: (Boolean) -> Unit,
    private val onBargeInDetected: () -> Unit
) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var monitorJob: Job? = null

    fun hasRecordAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun initializeTts() {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
                ttsReady = true
            }
        }.apply {
            setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    onSpeakingChanged(true)
                }

                override fun onDone(utteranceId: String?) {
                    onSpeakingChanged(false)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onSpeakingChanged(false)
                }
            })
        }
    }

    fun speak(text: String) {
        if (!ttsReady) initializeTts()
        val params = Bundle()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "voip_utt_${System.currentTimeMillis()}")
    }

    fun stopSpeaking() {
        runCatching { tts?.stop() }
        onSpeakingChanged(false)
    }

    /**
     * Monitors VoIP microphone energy during active VoIP calls to detect caller speech
     * and trigger instant TTS barge-in interruption.
     */
    fun startBargeInMonitor() {
        if (!hasRecordAudioPermission() || monitorJob?.isActive == true) return

        monitorJob = scope.launch(Dispatchers.IO) {
            val sampleRate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            var recorder: AudioRecord? = null
            try {
                recorder = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf
                )
                if (recorder.state != AudioRecord.STATE_INITIALIZED) return@launch
                recorder.startRecording()
                val buffer = ShortArray(minBuf / 2)
                var consecutiveLoudFrames = 0

                while (isActive) {
                    val read = recorder.read(buffer, 0, buffer.size)
                    if (read > 0) {
                        var sum = 0.0
                        for (i in 0 until read) {
                            val s = buffer[i].toDouble()
                            sum += s * s
                        }
                        val rms = sqrt(sum / read)
                        if (rms > BARGE_IN_RMS_THRESHOLD) {
                            consecutiveLoudFrames++
                            if (consecutiveLoudFrames >= 3 && tts?.isSpeaking == true) {
                                stopSpeaking()
                                onBargeInDetected()
                                consecutiveLoudFrames = 0
                            }
                        } else {
                            consecutiveLoudFrames = 0
                        }
                    }
                }
            } catch (_: SecurityException) {
                // Permission revoked
            } catch (_: Exception) {
                // Audio device unavailable
            } finally {
                runCatching {
                    recorder?.stop()
                    recorder?.release()
                }
            }
        }
    }

    fun stopBargeInMonitor() {
        monitorJob?.cancel()
        monitorJob = null
    }

    fun shutdown() {
        stopBargeInMonitor()
        stopSpeaking()
        runCatching { tts?.shutdown() }
        tts = null
        ttsReady = false
    }

    companion object {
        private const val BARGE_IN_RMS_THRESHOLD = 1800.0
    }
}

package com.callwise.ai.voip

import android.content.Context
import com.callwise.ai.ai.AiLanguage
import com.callwise.ai.ai.LocalAiEngine
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.atomic.AtomicLong

class VoipReceptionistManager(
    context: Context,
    private val aiEngine: LocalAiEngine
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val turnIdGen = AtomicLong(1L)

    private val _sipProfile = MutableStateFlow(SipProfile())
    val sipProfile: StateFlow<SipProfile> = _sipProfile.asStateFlow()

    private val _session = MutableStateFlow(VoipSessionSnapshot())
    val session: StateFlow<VoipSessionSnapshot> = _session.asStateFlow()

    private val voicePipeline = VoipVoicePipeline(
        context = context,
        scope = scope,
        onSpeakingChanged = { speaking ->
            _session.update { it.copy(isTtsSpeaking = speaking) }
        },
        onBargeInDetected = {
            _session.update {
                it.copy(
                    bargeInCount = it.bargeInCount + 1,
                    statusNote = "Caller interrupted AI (barge-in detected; TTS stopped)."
                )
            }
        }
    )

    fun hasAudioPermission(): Boolean = voicePipeline.hasRecordAudioPermission()

    fun updateSipProfile(profile: SipProfile) {
        _sipProfile.value = profile
        val note = if (profile.useLocalLoopback || profile.serverHost.isBlank()) {
            "Local VoIP Loopback Lab active (offline test mode)."
        } else {
            "SIP endpoint configured: ${profile.serverHost}:${profile.port} (${profile.transport})."
        }
        _session.update { it.copy(statusNote = note) }
    }

    fun startVoipCall(remoteParty: String, direction: CallDirection) {
        voicePipeline.initializeTts()
        voicePipeline.startBargeInMonitor()

        val party = remoteParty.trim().ifEmpty { "sip:caller@local.callwise" }
        val modeNote = if (_sipProfile.value.useLocalLoopback || _sipProfile.value.serverHost.isBlank()) {
            "[VoIP Local Lab] ${direction.displayName} call active. Offline AI answering."
        } else {
            "[VoIP SIP] ${direction.displayName} call via ${_sipProfile.value.serverHost}."
        }

        val (greeting, _) = aiEngine.generateVoipReply(
            callerUtterance = "",
            callerName = null,
            turnCount = 0,
            preferredLanguage = AiLanguage.ENGLISH
        )

        val greetingTurn = TranscriptTurn(
            id = turnIdGen.getAndIncrement(),
            speaker = "AI Receptionist",
            text = greeting,
            timestampMillis = System.currentTimeMillis()
        )

        _session.value = VoipSessionSnapshot(
            callSource = CallSource.VOIP,
            callState = VoipCallState.AI_CONVERSING,
            direction = direction,
            remoteParty = party,
            transcript = listOf(greetingTurn),
            isMicListening = voicePipeline.hasRecordAudioPermission(),
            statusNote = modeNote
        )

        voicePipeline.speak(greeting)
    }

    fun submitCallerUtterance(utterance: String) {
        val cleaned = utterance.trim()
        if (cleaned.isEmpty()) return
        val current = _session.value
        if (current.callState != VoipCallState.AI_CONVERSING &&
            current.callState != VoipCallState.USER_TAKEOVER
        ) {
            return
        }

        // Barge-in if AI was still speaking
        if (current.isTtsSpeaking) {
            voicePipeline.stopSpeaking()
        }

        val callerTurn = TranscriptTurn(
            id = turnIdGen.getAndIncrement(),
            speaker = "Caller",
            text = cleaned,
            timestampMillis = System.currentTimeMillis()
        )

        if (current.callState == VoipCallState.USER_TAKEOVER) {
            _session.update {
                it.copy(transcript = it.transcript + callerTurn)
            }
            return
        }

        val (reply, detectedIntent) = aiEngine.generateVoipReply(
            callerUtterance = cleaned,
            callerName = current.remoteParty,
            turnCount = current.transcript.size,
            preferredLanguage = AiLanguage.AUTO
        )

        val aiTurn = TranscriptTurn(
            id = turnIdGen.getAndIncrement(),
            speaker = "AI Receptionist",
            text = reply,
            timestampMillis = System.currentTimeMillis()
        )

        _session.update {
            it.copy(
                detectedIntent = detectedIntent ?: it.detectedIntent,
                transcript = it.transcript + callerTurn + aiTurn
            )
        }

        voicePipeline.speak(reply)
    }

    fun simulateBargeIn() {
        voicePipeline.stopSpeaking()
        _session.update {
            it.copy(
                bargeInCount = it.bargeInCount + 1,
                statusNote = "Barge-in triggered: AI speech interrupted immediately."
            )
        }
    }

    fun takeOverCall() {
        voicePipeline.stopSpeaking()
        val handoverTurn = TranscriptTurn(
            id = turnIdGen.getAndIncrement(),
            speaker = "System",
            text = "User took over the VoIP call. AI receptionist muted.",
            timestampMillis = System.currentTimeMillis()
        )
        _session.update {
            it.copy(
                callState = VoipCallState.USER_TAKEOVER,
                transcript = it.transcript + handoverTurn,
                statusNote = "User in control of VoIP call."
            )
        }
    }

    fun endVoipCall() {
        voicePipeline.stopBargeInMonitor()
        voicePipeline.stopSpeaking()

        val current = _session.value
        val fullTranscript = current.transcript
            .filter { it.speaker != "System" }
            .joinToString("\n") { "${it.speaker}: ${it.text}" }

        val summary = if (fullTranscript.isNotBlank()) {
            aiEngine.analyzeText(fullTranscript, AiLanguage.AUTO)
        } else {
            null
        }

        _session.update {
            it.copy(
                callState = VoipCallState.ENDED,
                isMicListening = false,
                isTtsSpeaking = false,
                summaryOutput = summary,
                statusNote = "VoIP call ended. Offline summary generated from live transcript."
            )
        }
    }

    fun release() {
        voicePipeline.shutdown()
    }
}

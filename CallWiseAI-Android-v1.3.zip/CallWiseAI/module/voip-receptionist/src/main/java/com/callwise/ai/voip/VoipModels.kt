package com.callwise.ai.voip

import com.callwise.ai.ai.CallIntelligenceOutput
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallSource
import com.callwise.ai.domain.model.CallerCategory

enum class VoipTransport {
    UDP,
    TCP,
    TLS
}

data class SipProfile(
    val displayName: String = "CallWise Local VoIP Lab",
    val sipUri: String = "sip:receptionist@local.callwise",
    val serverHost: String = "",
    val port: Int = 5060,
    val transport: VoipTransport = VoipTransport.TLS,
    val useLocalLoopback: Boolean = true
)

enum class VoipCallState(val displayName: String) {
    IDLE("Idle"),
    RINGING_INCOMING("Incoming VoIP Ringing"),
    DIALING_OUTGOING("Outgoing VoIP Dialing"),
    AI_CONVERSING("AI Receptionist Active"),
    USER_TAKEOVER("User Taken Over"),
    ENDED("VoIP Call Ended")
}

data class TranscriptTurn(
    val id: Long,
    val speaker: String,
    val text: String,
    val timestampMillis: Long
)

data class VoipSessionSnapshot(
    val callSource: CallSource = CallSource.VOIP,
    val callState: VoipCallState = VoipCallState.IDLE,
    val direction: CallDirection = CallDirection.INCOMING,
    val remoteParty: String = "",
    val detectedIntent: CallerCategory? = null,
    val transcript: List<TranscriptTurn> = emptyList(),
    val isTtsSpeaking: Boolean = false,
    val isMicListening: Boolean = false,
    val bargeInCount: Int = 0,
    val summaryOutput: CallIntelligenceOutput? = null,
    val statusNote: String = "Local VoIP Loopback Lab ready (offline, no paid SIP server required)."
)

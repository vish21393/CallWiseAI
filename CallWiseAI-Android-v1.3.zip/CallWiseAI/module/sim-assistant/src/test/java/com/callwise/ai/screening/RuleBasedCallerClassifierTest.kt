package com.callwise.ai.screening

import com.callwise.ai.data.local.CallRecordDao
import com.callwise.ai.data.local.CallRecordEntity
import com.callwise.ai.data.local.CallerRuleDao
import com.callwise.ai.data.local.CallerRuleEntity
import com.callwise.ai.data.local.TrustedContactDao
import com.callwise.ai.data.local.TrustedContactEntity
import com.callwise.ai.data.preferences.UserPreferences
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallSource
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.ContactTrustStatus
import com.callwise.ai.domain.model.RuleType
import com.callwise.ai.domain.model.SafetyRecommendation
import com.callwise.ai.domain.model.ScreeningAction
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RuleBasedCallerClassifierTest {

    @Test
    fun `saved contact overrides blocklist and stays advisory allow`() = runTest {
        val saved = TrustedContactEntity(
            id = 1L,
            contactId = 10L,
            displayName = "Mom",
            rawNumber = "+919876543210",
            normalizedNumber = "+919876543210",
            last10Digits = "9876543210",
            label = "Mobile",
            accountType = "com.google",
            updatedAt = 1000L
        )
        val blockRule = CallerRuleEntity(
            normalizedNumber = "+919876543210",
            last10Digits = "9876543210",
            displayLabel = "Blocked",
            ruleType = RuleType.BLOCKLIST,
            category = CallerCategory.SUSPECTED_SPAM,
            createdAt = 1000L
        )

        val classifier = RuleBasedCallerClassifier(
            trustedContactDao = FakeTrustedContactDao(saved),
            callerRuleDao = FakeCallerRuleDao(blockRule),
            callRecordDao = FakeCallRecordDao()
        )

        val decision = classifier.classify(
            rawNumber = "09876543210",
            callerDisplayName = "Spam",
            preferences = UserPreferences(enableExplicitBlockRules = true, enableExplicitSilenceRules = true),
            direction = CallDirection.INCOMING,
            callSource = CallSource.SIM
        )

        assertEquals(ScreeningAction.ADVISORY_ALLOW, decision.action)
        assertEquals(ContactTrustStatus.GOOGLE_SYNCED_CONTACT, decision.contactTrustStatus)
        assertEquals(SafetyRecommendation.SAVED_CONTACT_TRUSTED, decision.recommendation)
        assertTrue(decision.confidencePercent >= 95)
    }

    @Test
    fun `explicit silence rule silences incoming call only when enabled`() = runTest {
        val silenceRule = CallerRuleEntity(
            normalizedNumber = "+911401112222",
            last10Digits = "1401112222",
            displayLabel = "Loan Promo",
            ruleType = RuleType.SILENCELIST,
            category = CallerCategory.PROMO_LOAN,
            createdAt = 1000L
        )
        val classifier = RuleBasedCallerClassifier(
            trustedContactDao = FakeTrustedContactDao(null),
            callerRuleDao = FakeCallerRuleDao(silenceRule),
            callRecordDao = FakeCallRecordDao()
        )

        val advisoryDecision = classifier.classify(
            rawNumber = "+911401112222",
            callerDisplayName = null,
            preferences = UserPreferences(enableExplicitSilenceRules = false),
            direction = CallDirection.INCOMING
        )
        assertEquals(ScreeningAction.ADVISORY_ALLOW, advisoryDecision.action)

        val silencedDecision = classifier.classify(
            rawNumber = "+911401112222",
            callerDisplayName = null,
            preferences = UserPreferences(enableExplicitSilenceRules = true),
            direction = CallDirection.INCOMING
        )
        assertEquals(ScreeningAction.SILENCE_CALL, silencedDecision.action)
    }
}

private class FakeTrustedContactDao(private val match: TrustedContactEntity?) : TrustedContactDao {
    override suspend fun findMatch(normalized: String, last10: String): TrustedContactEntity? = match
    override fun observeAll(): Flow<List<TrustedContactEntity>> = flowOf(listOfNotNull(match))
    override fun observeDistinctContactCount(): Flow<Int> = flowOf(if (match != null) 1 else 0)
    override suspend fun getNumberCount(): Int = if (match != null) 1 else 0
    override suspend fun insertAll(contacts: List<TrustedContactEntity>) {}
    override suspend fun deleteAll() {}
    override suspend fun replaceAll(contacts: List<TrustedContactEntity>) {}
}

private class FakeCallerRuleDao(private val match: CallerRuleEntity?) : CallerRuleDao {
    override suspend fun findRule(normalized: String, last10: String): CallerRuleEntity? = match
    override fun observeAll(): Flow<List<CallerRuleEntity>> = flowOf(listOfNotNull(match))
    override fun observeByType(type: RuleType): Flow<List<CallerRuleEntity>> = flowOf(emptyList())
    override suspend fun upsert(rule: CallerRuleEntity) {}
    override suspend fun deleteByNumber(normalizedNumber: String) {}
    override suspend fun deleteAll() {}
}

private class FakeCallRecordDao : CallRecordDao {
    override fun observeAll(): Flow<List<CallRecordEntity>> = flowOf(emptyList())
    override fun observeById(id: Long): Flow<CallRecordEntity?> = flowOf(null)
    override suspend fun getById(id: Long): CallRecordEntity? = null
    override fun observeHistoryForNumber(normalized: String, last10: String): Flow<List<CallRecordEntity>> = flowOf(emptyList())
    override suspend fun getRecentHistoryForNumber(normalized: String, last10: String, excludeId: Long): List<CallRecordEntity> = emptyList()
    override suspend fun getLatestForNumber(normalized: String, last10: String): CallRecordEntity? = null
    override suspend fun searchNotesAndSummaries(query: String): List<CallRecordEntity> = emptyList()
    override fun observeSince(startOfDayMillis: Long): Flow<List<CallRecordEntity>> = flowOf(emptyList())
    override suspend fun getSince(startOfDayMillis: Long): List<CallRecordEntity> = emptyList()
    override fun observePendingFollowUps(): Flow<List<CallRecordEntity>> = flowOf(emptyList())
    override suspend fun getPendingFollowUps(): List<CallRecordEntity> = emptyList()
    override suspend fun insert(record: CallRecordEntity): Long = 1L
    override suspend fun update(record: CallRecordEntity) {}
    override suspend fun updateCategory(id: Long, category: CallerCategory, confirmed: Boolean) {}
    override suspend fun updateStatusAndDuration(id: Long, status: CallStatus, durationSeconds: Long?) {}
    override suspend fun updateNotes(id: Long, notes: String?) {}
    override suspend fun updateFollowUp(id: Long, followUpAt: Long?, done: Boolean) {}
    override suspend fun updateTranscriptAndSummary(id: Long, transcript: String?, summary: String?) {}
    override suspend fun deleteOlderThan(cutoffMillis: Long): Int = 0
    override suspend fun deleteAll() {}
}

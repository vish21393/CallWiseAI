package com.callwise.ai.contacts

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.callwise.ai.sim.SimAssistantHost

class ContactsSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val host = applicationContext as? SimAssistantHost ?: return Result.failure()
        return when (host.simContainer.contactsSyncManager.syncContacts()) {
            is SyncState.Success,
            SyncState.PermissionMissing -> Result.success()
            is SyncState.Error -> Result.retry()
            else -> Result.success()
        }
    }
}

package com.callwise.ai.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.sim.SimAssistantHost
import java.util.Calendar
import java.util.concurrent.TimeUnit

class DailySummaryWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val host = applicationContext as? SimAssistantHost ?: return Result.failure()
        val container = host.simContainer
        val prefs = container.preferencesRepository.getSnapshot()

        if (prefs.retentionDays > 0) {
            val cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(prefs.retentionDays.toLong())
            container.callRecordDao.deleteOlderThan(cutoff)
        }

        if (!prefs.dailySummaryEnabled) return Result.success()

        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val todaysCalls = container.callRecordDao.getSince(startOfDay)
        val pendingFollowUps = container.callRecordDao.getPendingFollowUps()

        if (todaysCalls.isNotEmpty() || pendingFollowUps.isNotEmpty()) {
            container.notificationManager.notifyDailySummary(
                totalCalls = todaysCalls.size,
                importantCalls = todaysCalls.count { it.category.isImportant },
                flaggedCalls = todaysCalls.count {
                    it.category.isPromotional || it.category == CallerCategory.SUSPECTED_SPAM
                },
                missedCalls = todaysCalls.count { it.status == CallStatus.MISSED },
                pendingFollowUps = pendingFollowUps.size
            )
        }

        return Result.success()
    }
}

object DailySummaryScheduler {
    private const val WORK_NAME = "callwise_daily_summary"

    fun schedule(context: Context, enabled: Boolean, hour: Int, minute: Int) {
        val workManager = WorkManager.getInstance(context)
        if (!enabled) {
            workManager.cancelUniqueWork(WORK_NAME)
            return
        }

        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
            set(Calendar.MINUTE, minute.coerceIn(0, 59))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (before(now)) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val initialDelayMs = (target.timeInMillis - now.timeInMillis).coerceAtLeast(60_000L)

        val request = PeriodicWorkRequestBuilder<DailySummaryWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(initialDelayMs, TimeUnit.MILLISECONDS)
            .build()

        workManager.enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
}

package com.callwise.ai.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.callwise.ai.data.local.CallerRuleEntity
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.ContactTrustStatus
import com.callwise.ai.domain.model.RuleType
import com.callwise.ai.domain.model.SafetyRecommendation
import com.callwise.ai.domain.util.PhoneNumberNormalizer
import com.callwise.ai.sim.SimAssistantHost
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Module A floating SIM call assistant overlay over Google Phone.
 * Shows [SIM] label, direction, confidence %, trust status, previous history, notes,
 * reminders, and quick-tag buttons (Important / Trusted / Spam / Follow-up) in Expanded mode.
 */
class CallOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var isExpanded: Boolean = false
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISMISS) {
            removeOverlayAndStop()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            removeOverlayAndStop()
            return START_NOT_STICKY
        }

        val recordId = intent?.getLongExtra(EXTRA_RECORD_ID, -1L) ?: -1L
        val rawNumber = intent?.getStringExtra(EXTRA_RAW_NUMBER).orEmpty().ifBlank { "Private Number" }
        val callerName = intent?.getStringExtra(EXTRA_CALLER_NAME)
        val direction = runCatching {
            CallDirection.valueOf(intent?.getStringExtra(EXTRA_DIRECTION) ?: CallDirection.INCOMING.name)
        }.getOrDefault(CallDirection.INCOMING)
        val trustStatus = runCatching {
            ContactTrustStatus.valueOf(
                intent?.getStringExtra(EXTRA_TRUST_STATUS) ?: ContactTrustStatus.UNKNOWN.name
            )
        }.getOrDefault(ContactTrustStatus.UNKNOWN)
        val category = runCatching {
            CallerCategory.valueOf(
                intent?.getStringExtra(EXTRA_CATEGORY_NAME) ?: CallerCategory.UNKNOWN.name
            )
        }.getOrDefault(CallerCategory.UNKNOWN)
        val confidencePercent = intent?.getIntExtra(EXTRA_CONFIDENCE_PERCENT, 50) ?: 50
        val isUserConfirmed = intent?.getBooleanExtra(EXTRA_IS_USER_CONFIRMED, false) ?: false
        val recommendation = runCatching {
            SafetyRecommendation.valueOf(
                intent?.getStringExtra(EXTRA_RECOMMENDATION)
                    ?: SafetyRecommendation.UNKNOWN_VERIFY_BEFORE_ANSWERING.name
            )
        }.getOrDefault(SafetyRecommendation.UNKNOWN_VERIFY_BEFORE_ANSWERING)
        val reason = intent?.getStringExtra(EXTRA_REASON).orEmpty()
        val historySummary = intent?.getStringExtra(EXTRA_HISTORY_SUMMARY).orEmpty()
        val notesSummary = intent?.getStringExtra(EXTRA_NOTES_SUMMARY)
        val followUpSummary = intent?.getStringExtra(EXTRA_FOLLOW_UP_SUMMARY)

        isExpanded = false

        showOrUpdateOverlay(
            recordId = recordId,
            rawNumber = rawNumber,
            callerName = callerName,
            direction = direction,
            trustStatus = trustStatus,
            category = category,
            confidencePercent = confidencePercent,
            isUserConfirmed = isUserConfirmed,
            recommendation = recommendation,
            reason = reason,
            historySummary = historySummary,
            notesSummary = notesSummary,
            followUpSummary = followUpSummary
        )

        return START_NOT_STICKY
    }

    private fun showOrUpdateOverlay(
        recordId: Long,
        rawNumber: String,
        callerName: String?,
        direction: CallDirection,
        trustStatus: ContactTrustStatus,
        category: CallerCategory,
        confidencePercent: Int,
        isUserConfirmed: Boolean,
        recommendation: SafetyRecommendation,
        reason: String,
        historySummary: String,
        notesSummary: String?,
        followUpSummary: String?
    ) {
        removeOverlayViewOnly()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val metrics = resources.displayMetrics
        val density = metrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val cardWidth = (metrics.widthPixels - dp(24)).coerceAtMost(dp(440))

        val rootCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F5141B1F"))
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), Color.parseColor("#FF2E4752"))
            }
            elevation = dp(10).toFloat()
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val brandText = TextView(this).apply {
            text = "CallWise AI • SIM ${direction.displayName.uppercase()}"
            textSize = 11f
            setTextColor(Color.parseColor("#FF6BC2D9"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val expandBtn = Button(this).apply {
            text = "Expand"
            textSize = 11f
            setPadding(dp(8), 0, dp(8), 0)
            minHeight = dp(28)
            minimumHeight = dp(28)
        }

        val closeBtn = TextView(this).apply {
            text = "✕"
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(10), dp(2), dp(4), dp(2))
            setOnClickListener { removeOverlayAndStop() }
        }

        headerRow.addView(brandText)
        headerRow.addView(expandBtn)
        headerRow.addView(closeBtn)

        val titleText = TextView(this).apply {
            text = callerName?.takeIf { it.isNotBlank() } ?: rawNumber
            textSize = 17f
            setTextColor(Color.WHITE)
            setPadding(0, dp(4), 0, dp(2))
        }

        val trustAndNumberText = TextView(this).apply {
            text = "$rawNumber • ${trustStatus.displayName}"
            textSize = 12f
            setTextColor(Color.parseColor("#FFD1D5DB"))
        }

        val recColor = when (recommendation) {
            SafetyRecommendation.SAVED_CONTACT_TRUSTED -> Color.parseColor("#FF6EE7B7")
            SafetyRecommendation.KNOWN_CALLER_REVIEW_HISTORY -> Color.parseColor("#FF93C5FD")
            SafetyRecommendation.UNKNOWN_VERIFY_BEFORE_ANSWERING -> Color.parseColor("#FFFDE68A")
            SafetyRecommendation.POSSIBLE_PROMOTIONAL_CALL,
            SafetyRecommendation.SUSPECTED_SPAM_BE_CAUTIOUS -> Color.parseColor("#FFFCA5A5")
        }

        val recommendationText = TextView(this).apply {
            text = recommendation.label
            textSize = 13f
            setTextColor(recColor)
            setPadding(0, dp(4), 0, dp(2))
        }

        val classificationSource = if (isUserConfirmed) "User-confirmed" else "Locally suspected"
        val categoryText = TextView(this).apply {
            text = "${category.displayName} • Confidence: $confidencePercent% ($classificationSource)"
            textSize = 11.5f
            setTextColor(Color.parseColor("#FF9CA3AF"))
        }

        val detailsScroll = ScrollView(this).apply {
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(8)
            }
        }

        val detailsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        detailsBox.addView(TextView(this).apply {
            text = "Assessment: $reason"
            textSize = 12f
            setTextColor(Color.parseColor("#FFE5E7EB"))
            setPadding(0, 0, 0, dp(6))
        })

        if (!followUpSummary.isNullOrBlank()) {
            detailsBox.addView(TextView(this).apply {
                text = "Reminder: $followUpSummary"
                textSize = 12f
                setTextColor(Color.parseColor("#FFFDE68A"))
                setPadding(0, 0, 0, dp(6))
            })
        }

        if (!notesSummary.isNullOrBlank()) {
            detailsBox.addView(TextView(this).apply {
                text = "Saved Note: $notesSummary"
                textSize = 12f
                setTextColor(Color.parseColor("#FF93C5FD"))
                setPadding(0, 0, 0, dp(6))
            })
        }

        detailsBox.addView(TextView(this).apply {
            text = "Previous Interactions:\n${historySummary.ifBlank { "No previous local history." }}"
            textSize = 11.5f
            setTextColor(Color.parseColor("#FFD1D5DB"))
            setPadding(0, 0, 0, dp(8))
        })

        val feedbackStatus = TextView(this).apply {
            text = ""
            textSize = 11f
            setTextColor(Color.parseColor("#FF6EE7B7"))
            visibility = View.GONE
        }

        val tagRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        fun makeTagBtn(label: String, onClick: () -> Unit): Button {
            return Button(this).apply {
                text = label
                textSize = 10.5f
                setPadding(dp(4), 0, dp(4), 0)
                minHeight = dp(30)
                minimumHeight = dp(30)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    onClick()
                    feedbackStatus.text = "Saved: $label"
                    feedbackStatus.visibility = View.VISIBLE
                }
            }
        }

        tagRow.addView(makeTagBtn("Important") {
            applyQuickTag(recordId, rawNumber, callerName, CallerCategory.PERSONAL_TRUSTED, RuleType.ALLOWLIST)
        })
        tagRow.addView(makeTagBtn("Trusted") {
            applyQuickTag(recordId, rawNumber, callerName, CallerCategory.PERSONAL_TRUSTED, RuleType.ALLOWLIST)
        })
        tagRow.addView(makeTagBtn("Spam") {
            applyQuickTag(recordId, rawNumber, callerName, CallerCategory.SUSPECTED_SPAM, RuleType.BLOCKLIST)
        })
        tagRow.addView(makeTagBtn("Follow-up") {
            markFollowUp(recordId)
        })

        detailsBox.addView(tagRow)
        detailsBox.addView(feedbackStatus)

        detailsBox.addView(TextView(this).apply {
            text = "Advisory only • Use Google Phone controls to answer or end call."
            textSize = 10.5f
            setTextColor(Color.parseColor("#FF9CA3AF"))
            setPadding(0, dp(6), 0, 0)
        })

        detailsScroll.addView(detailsBox)

        expandBtn.setOnClickListener {
            isExpanded = !isExpanded
            detailsScroll.visibility = if (isExpanded) View.VISIBLE else View.GONE
            expandBtn.text = if (isExpanded) "Minimise" else "Expand"
        }

        rootCard.addView(headerRow)
        rootCard.addView(titleText)
        rootCard.addView(trustAndNumberText)
        rootCard.addView(recommendationText)
        rootCard.addView(categoryText)
        rootCard.addView(detailsScroll)

        @Suppress("DEPRECATION")
        val params = WindowManager.LayoutParams(
            cardWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(36)
        }

        var initialY = 0
        var initialTouchY = 0f
        rootCard.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = params.y
                    initialTouchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    val maxOffset = (metrics.heightPixels - dp(160)).coerceAtLeast(dp(40))
                    params.y = (initialY + (event.rawY - initialTouchY).toInt()).coerceIn(dp(8), maxOffset)
                    runCatching { wm.updateViewLayout(rootCard, params) }
                    true
                }
                else -> false
            }
        }

        runCatching {
            wm.addView(rootCard, params)
            overlayView = rootCard
        }.onFailure {
            stopSelf()
        }
    }

    private fun applyQuickTag(
        recordId: Long,
        rawNumber: String,
        callerName: String?,
        category: CallerCategory,
        ruleType: RuleType
    ) {
        val host = applicationContext as? SimAssistantHost ?: return
        val norm = PhoneNumberNormalizer.normalize(rawNumber)
        serviceScope.launch {
            runCatching {
                if (recordId > 0L) {
                    host.simContainer.callRecordDao.updateCategory(recordId, category, confirmed = true)
                }
                if (norm.normalized.isNotEmpty()) {
                    host.simContainer.callerRuleDao.upsert(
                        CallerRuleEntity(
                            normalizedNumber = norm.normalized,
                            last10Digits = norm.last10Digits,
                            displayLabel = callerName?.trim()?.ifEmpty { null },
                            ruleType = ruleType,
                            category = category,
                            createdAt = System.currentTimeMillis()
                        )
                    )
                }
            }
        }
    }

    private fun markFollowUp(recordId: Long) {
        if (recordId <= 0L) return
        val host = applicationContext as? SimAssistantHost ?: return
        serviceScope.launch {
            runCatching {
                val tomorrow = System.currentTimeMillis() + 24L * 60 * 60 * 1000
                host.simContainer.callRecordDao.updateFollowUp(recordId, tomorrow, done = false)
            }
        }
    }

    private fun removeOverlayViewOnly() {
        val view = overlayView ?: return
        runCatching { windowManager?.removeView(view) }
        overlayView = null
    }

    private fun removeOverlayAndStop() {
        removeOverlayViewOnly()
        stopSelf()
    }

    override fun onDestroy() {
        removeOverlayViewOnly()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val ACTION_DISMISS = "com.callwise.ai.overlay.ACTION_DISMISS"
        private const val EXTRA_RECORD_ID = "extra_record_id"
        private const val EXTRA_RAW_NUMBER = "extra_raw_number"
        private const val EXTRA_CALLER_NAME = "extra_caller_name"
        private const val EXTRA_DIRECTION = "extra_direction"
        private const val EXTRA_TRUST_STATUS = "extra_trust_status"
        private const val EXTRA_CATEGORY_NAME = "extra_category_name"
        private const val EXTRA_CONFIDENCE_PERCENT = "extra_confidence_percent"
        private const val EXTRA_IS_USER_CONFIRMED = "extra_is_user_confirmed"
        private const val EXTRA_RECOMMENDATION = "extra_recommendation"
        private const val EXTRA_REASON = "extra_reason"
        private const val EXTRA_HISTORY_SUMMARY = "extra_history_summary"
        private const val EXTRA_NOTES_SUMMARY = "extra_notes_summary"
        private const val EXTRA_FOLLOW_UP_SUMMARY = "extra_follow_up_summary"

        fun show(
            context: Context,
            recordId: Long,
            rawNumber: String,
            callerName: String?,
            direction: CallDirection,
            trustStatus: ContactTrustStatus,
            category: CallerCategory,
            confidencePercent: Int,
            isUserConfirmed: Boolean,
            recommendation: SafetyRecommendation,
            reason: String,
            historySummary: String,
            notesSummary: String?,
            followUpSummary: String?
        ) {
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, CallOverlayService::class.java).apply {
                putExtra(EXTRA_RECORD_ID, recordId)
                putExtra(EXTRA_RAW_NUMBER, rawNumber)
                putExtra(EXTRA_CALLER_NAME, callerName)
                putExtra(EXTRA_DIRECTION, direction.name)
                putExtra(EXTRA_TRUST_STATUS, trustStatus.name)
                putExtra(EXTRA_CATEGORY_NAME, category.name)
                putExtra(EXTRA_CONFIDENCE_PERCENT, confidencePercent)
                putExtra(EXTRA_IS_USER_CONFIRMED, isUserConfirmed)
                putExtra(EXTRA_RECOMMENDATION, recommendation.name)
                putExtra(EXTRA_REASON, reason)
                putExtra(EXTRA_HISTORY_SUMMARY, historySummary)
                putExtra(EXTRA_NOTES_SUMMARY, notesSummary)
                putExtra(EXTRA_FOLLOW_UP_SUMMARY, followUpSummary)
            }
            runCatching { context.startService(intent) }
        }

        fun dismiss(context: Context) {
            val intent = Intent(context, CallOverlayService::class.java).apply {
                action = ACTION_DISMISS
            }
            runCatching { context.startService(intent) }
        }
    }
}

package com.callwise.ai.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.callwise.ai.data.preferences.UserPreferences
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.ScreeningDecision
import com.callwise.ai.sim.R

class CallNotificationManager(private val context: Context) {

    fun createChannels() {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val importantChannel = NotificationChannel(
            CHANNEL_IMPORTANT_CALLS,
            "Important Calls",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alerts for personal, professional, banking, and insurance servicing calls."
        }

        val unknownChannel = NotificationChannel(
            CHANNEL_UNKNOWN_WARNINGS,
            "Unknown Caller Warnings",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Offline warnings when an unrecognised number calls."
        }

        val summaryChannel = NotificationChannel(
            CHANNEL_DAILY_SUMMARY,
            "Daily Call Summary",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Daily offline digest of screened calls and pending follow-ups."
        }

        manager.createNotificationChannels(listOf(importantChannel, unknownChannel, summaryChannel))
    }

    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun notifyScreenedCall(
        recordId: Long,
        rawNumber: String,
        decision: ScreeningDecision,
        preferences: UserPreferences
    ) {
        if (!hasNotificationPermission()) return

        val shouldNotifyImportant = when (decision.category) {
            CallerCategory.PERSONAL_TRUSTED -> preferences.notifyPersonal
            CallerCategory.PROFESSIONAL_RECRUITER -> preferences.notifyProfessional
            CallerCategory.BANK_FINANCIAL -> preferences.notifyBanking
            CallerCategory.INSURANCE_SERVICING -> preferences.notifyInsurance
            else -> false
        }

        val shouldNotifyUnknown = !decision.isSavedContact &&
            !decision.category.isImportant &&
            preferences.notifyUnknownWarning

        if (!shouldNotifyImportant && !shouldNotifyUnknown) return

        val channelId = if (shouldNotifyImportant) CHANNEL_IMPORTANT_CALLS else CHANNEL_UNKNOWN_WARNINGS
        val displayCaller = decision.callerName?.takeIf { it.isNotBlank() } ?: rawNumber
        val title = "[${decision.callSource.displayName}] ${decision.recommendation.label}: $displayCaller"
        val body = "${decision.category.displayName} (${decision.confidencePercent}%) • ${decision.reason}"

        val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_CALL_RECORD_ID, recordId)
        } ?: return

        val pendingIntent = PendingIntent.getActivity(
            context,
            recordId.toInt(),
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_callwise_notify)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(
                if (shouldNotifyImportant) NotificationCompat.PRIORITY_HIGH
                else NotificationCompat.PRIORITY_DEFAULT
            )
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(recordId.toInt(), notification)
        }
    }

    fun notifyDailySummary(
        totalCalls: Int,
        importantCalls: Int,
        flaggedCalls: Int,
        missedCalls: Int,
        pendingFollowUps: Int
    ) {
        if (!hasNotificationPermission()) return

        val summaryText = buildString {
            append("Today: $totalCalls calls • $importantCalls important • ")
            append("$flaggedCalls flagged • $missedCalls missed")
            if (pendingFollowUps > 0) {
                append(" • $pendingFollowUps pending follow-up(s)")
            }
        }

        val launchIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_OPEN_DAILY_SUMMARY, true)
        } ?: return

        val pendingIntent = PendingIntent.getActivity(
            context,
            DAILY_SUMMARY_NOTIFICATION_ID,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_DAILY_SUMMARY)
            .setSmallIcon(R.drawable.ic_callwise_notify)
            .setContentTitle("CallWise AI Daily Summary")
            .setContentText(summaryText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(summaryText))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        runCatching {
            NotificationManagerCompat.from(context).notify(DAILY_SUMMARY_NOTIFICATION_ID, notification)
        }
    }

    companion object {
        const val CHANNEL_IMPORTANT_CALLS = "important_calls"
        const val CHANNEL_UNKNOWN_WARNINGS = "unknown_caller_warnings"
        const val CHANNEL_DAILY_SUMMARY = "daily_summary"
        const val EXTRA_CALL_RECORD_ID = "extra_call_record_id"
        const val EXTRA_OPEN_DAILY_SUMMARY = "extra_open_daily_summary"
        private const val DAILY_SUMMARY_NOTIFICATION_ID = 9001
    }
}

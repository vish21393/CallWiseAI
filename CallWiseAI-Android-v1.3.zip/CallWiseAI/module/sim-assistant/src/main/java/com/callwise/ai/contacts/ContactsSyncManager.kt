package com.callwise.ai.contacts

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.callwise.ai.data.local.TrustedContactDao
import com.callwise.ai.data.local.TrustedContactEntity
import com.callwise.ai.data.preferences.UserPreferencesRepository
import com.callwise.ai.domain.util.PhoneNumberNormalizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

sealed interface SyncState {
    data object Idle : SyncState
    data object Syncing : SyncState
    data class Success(val contactCount: Int, val numberCount: Int, val timestamp: Long) : SyncState
    data object PermissionMissing : SyncState
    data class Error(val message: String) : SyncState
}

class ContactsSyncManager(
    private val context: Context,
    private val trustedContactDao: TrustedContactDao,
    private val preferencesRepository: UserPreferencesRepository
) {
    private val syncMutex = Mutex()
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    fun hasContactsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    suspend fun syncContacts(): SyncState = syncMutex.withLock {
        if (!hasContactsPermission()) {
            _syncState.value = SyncState.PermissionMissing
            return SyncState.PermissionMissing
        }

        _syncState.value = SyncState.Syncing

        return withContext(Dispatchers.IO) {
            try {
                val now = System.currentTimeMillis()
                val projection = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.TYPE,
                    ContactsContract.CommonDataKinds.Phone.LABEL,
                    ContactsContract.RawContacts.ACCOUNT_TYPE
                )

                val deduplicatedByNormalized = LinkedHashMap<String, TrustedContactEntity>()
                val distinctContactIds = HashSet<Long>()

                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    null,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY} ASC"
                )?.use { cursor ->
                    val idIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
                    val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY)
                    val numIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    val typeIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.TYPE)
                    val labelIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.LABEL)
                    val acctIdx = cursor.getColumnIndex(ContactsContract.RawContacts.ACCOUNT_TYPE)

                    while (cursor.moveToNext()) {
                        val contactId = cursor.getLong(idIdx)
                        val displayName = cursor.getString(nameIdx)?.trim().orEmpty()
                            .ifEmpty { "Saved Contact" }
                        val rawNumber = cursor.getString(numIdx)?.trim().orEmpty()
                        if (rawNumber.isEmpty()) continue

                        val normalized = PhoneNumberNormalizer.normalize(rawNumber)
                        if (normalized.normalized.isEmpty()) continue

                        val type = cursor.getInt(typeIdx)
                        val customLabel = cursor.getString(labelIdx)
                        val typeLabel = ContactsContract.CommonDataKinds.Phone.getTypeLabel(
                            context.resources,
                            type,
                            customLabel
                        )?.toString()
                        val accountType = if (acctIdx >= 0) cursor.getString(acctIdx) else null

                        distinctContactIds.add(contactId)

                        val dedupKey = "${normalized.normalized}|${normalized.last10Digits}"
                        val existing = deduplicatedByNormalized[dedupKey]
                        if (existing == null) {
                            deduplicatedByNormalized[dedupKey] = TrustedContactEntity(
                                contactId = contactId,
                                displayName = displayName,
                                rawNumber = rawNumber,
                                normalizedNumber = normalized.normalized,
                                last10Digits = normalized.last10Digits,
                                label = typeLabel,
                                accountType = accountType,
                                updatedAt = now
                            )
                        } else if (existing.accountType == null && accountType != null) {
                            deduplicatedByNormalized[dedupKey] = existing.copy(accountType = accountType)
                        }
                    }
                }

                val entities = deduplicatedByNormalized.values.toList()
                trustedContactDao.replaceAll(entities)
                preferencesRepository.updateContactSyncMetadata(
                    syncTimeMillis = now,
                    contactCount = distinctContactIds.size
                )

                val result = SyncState.Success(
                    contactCount = distinctContactIds.size,
                    numberCount = entities.size,
                    timestamp = now
                )
                _syncState.value = result
                result
            } catch (_: SecurityException) {
                _syncState.value = SyncState.PermissionMissing
                SyncState.PermissionMissing
            } catch (e: Exception) {
                val err = SyncState.Error(e.message ?: "Contact sync failed")
                _syncState.value = err
                err
            }
        }
    }

    suspend fun findTrustedContact(rawNumber: String?): TrustedContactEntity? {
        if (rawNumber.isNullOrBlank()) return null
        return try {
            val normalized = PhoneNumberNormalizer.normalize(rawNumber)
            if (normalized.normalized.isEmpty()) return null
            trustedContactDao.findMatch(normalized.normalized, normalized.last10Digits)
        } catch (_: Exception) {
            null
        }
    }
}

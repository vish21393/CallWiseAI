package com.callwise.ai.screening

import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.ScreeningAction
import com.callwise.ai.sim.SimAssistantHost
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Module A (SIM Call Assistant) CallScreeningService.
 * Default behaviour is strictly advisory (respondAllow). Explicit Silence or Block responses
 * are sent ONLY for incoming calls when the user explicitly created a matching rule and
 * enabled rule enforcement in Settings. Outgoing calls always receive respondAllow() immediately.
 */
class CallWiseScreeningService : CallScreeningService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onScreenCall(callDetails: Call.Details) {
        val host = applicationContext as? SimAssistantHost
        if (host == null) {
            respondAllow(callDetails)
            return
        }

        val rawNumber = callDetails.handle?.schemeSpecificPart
        val callerDisplayName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            callDetails.callerDisplayName
        } else {
            null
        }

        val direction = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            callDetails.callDirection == Call.Details.DIRECTION_OUTGOING
        ) {
            CallDirection.OUTGOING
        } else {
            CallDirection.INCOMING
        }

        // Outgoing calls must never receive incoming-call silence/block actions
        if (direction == CallDirection.OUTGOING) {
            respondAllow(callDetails)
            serviceScope.launch {
                runCatching {
                    host.simContainer.callCoordinator.onCallScreened(
                        rawNumber = rawNumber,
                        callerDisplayName = callerDisplayName,
                        direction = CallDirection.OUTGOING
                    )
                }
            }
            return
        }

        serviceScope.launch {
            val decision = withTimeoutOrNull(SCREENING_TIMEOUT_MS) {
                runCatching {
                    val prefs = host.simContainer.preferencesRepository.getSnapshot()
                    host.simContainer.classifier.classify(
                        rawNumber = rawNumber,
                        callerDisplayName = callerDisplayName,
                        preferences = prefs,
                        direction = CallDirection.INCOMING
                    )
                }.getOrNull()
            }

            when (decision?.action) {
                ScreeningAction.BLOCK_CALL -> respondBlock(callDetails)
                ScreeningAction.SILENCE_CALL -> respondSilence(callDetails)
                ScreeningAction.ADVISORY_ALLOW, null -> respondAllow(callDetails)
            }

            runCatching {
                host.simContainer.callCoordinator.onCallScreenedWithDecision(
                    rawNumber = rawNumber,
                    callerDisplayName = callerDisplayName,
                    direction = CallDirection.INCOMING,
                    precomputedDecision = decision
                )
            }
        }
    }

    private fun respondAllow(callDetails: Call.Details) {
        respondToCall(
            callDetails,
            CallResponse.Builder()
                .setDisallowCall(false)
                .setRejectCall(false)
                .setSilenceCall(false)
                .setSkipCallLog(false)
                .setSkipNotification(false)
                .build()
        )
    }

    private fun respondSilence(callDetails: Call.Details) {
        respondToCall(
            callDetails,
            CallResponse.Builder()
                .setDisallowCall(false)
                .setRejectCall(false)
                .setSilenceCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(false)
                .build()
        )
    }

    private fun respondBlock(callDetails: Call.Details) {
        respondToCall(
            callDetails,
            CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipCallLog(false)
                .setSkipNotification(true)
                .build()
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    companion object {
        private const val SCREENING_TIMEOUT_MS = 2000L
    }
}

package com.callwise.ai.sim

import android.content.Context
import com.callwise.ai.contacts.ContactsChangeObserver
import com.callwise.ai.contacts.ContactsSyncManager
import com.callwise.ai.data.local.CallWiseDatabase
import com.callwise.ai.data.preferences.UserPreferencesRepository
import com.callwise.ai.notifications.CallNotificationManager
import com.callwise.ai.screening.CallIntelligenceCoordinator
import com.callwise.ai.screening.CallStateMonitor
import com.callwise.ai.screening.RuleBasedCallerClassifier

interface SimAssistantHost {
    val simContainer: SimAssistantContainer
}

class SimAssistantContainer(context: Context) {
    private val appContext = context.applicationContext

    val database: CallWiseDatabase by lazy { CallWiseDatabase.getInstance(appContext) }
    val trustedContactDao get() = database.trustedContactDao()
    val callerRuleDao get() = database.callerRuleDao()
    val callRecordDao get() = database.callRecordDao()

    val preferencesRepository by lazy { UserPreferencesRepository(appContext) }
    val contactsSyncManager by lazy {
        ContactsSyncManager(appContext, trustedContactDao, preferencesRepository)
    }
    val contactsChangeObserver by lazy { ContactsChangeObserver(appContext) }
    val classifier by lazy {
        RuleBasedCallerClassifier(trustedContactDao, callerRuleDao, callRecordDao)
    }
    val notificationManager by lazy { CallNotificationManager(appContext) }
    val callCoordinator by lazy {
        CallIntelligenceCoordinator(
            context = appContext,
            classifier = classifier,
            callRecordDao = callRecordDao,
            preferencesRepository = preferencesRepository,
            notificationManager = notificationManager
        )
    }
    val callStateMonitor by lazy { CallStateMonitor(appContext, callCoordinator) }
}

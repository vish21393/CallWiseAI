package com.callwise.ai.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallSource
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.RuleType

class CallWiseTypeConverters {
    @TypeConverter
    fun fromCallerCategory(value: CallerCategory): String = value.name

    @TypeConverter
    fun toCallerCategory(value: String): CallerCategory =
        runCatching { CallerCategory.valueOf(value) }.getOrDefault(CallerCategory.UNKNOWN)

    @TypeConverter
    fun fromCallStatus(value: CallStatus): String = value.name

    @TypeConverter
    fun toCallStatus(value: String): CallStatus =
        runCatching { CallStatus.valueOf(value) }.getOrDefault(CallStatus.ALLOWED_SCREENED)

    @TypeConverter
    fun fromCallDirection(value: CallDirection): String = value.name

    @TypeConverter
    fun toCallDirection(value: String): CallDirection =
        runCatching { CallDirection.valueOf(value) }.getOrDefault(CallDirection.INCOMING)

    @TypeConverter
    fun fromCallSource(value: CallSource): String = value.name

    @TypeConverter
    fun toCallSource(value: String): CallSource =
        runCatching { CallSource.valueOf(value) }.getOrDefault(CallSource.SIM)

    @TypeConverter
    fun fromRuleType(value: RuleType): String = value.name

    @TypeConverter
    fun toRuleType(value: String): RuleType =
        runCatching { RuleType.valueOf(value) }.getOrDefault(RuleType.ALLOWLIST)
}

@Database(
    entities = [
        TrustedContactEntity::class,
        CallerRuleEntity::class,
        CallRecordEntity::class
    ],
    version = 3,
    exportSchema = true
)
@TypeConverters(CallWiseTypeConverters::class)
abstract class CallWiseDatabase : RoomDatabase() {
    abstract fun trustedContactDao(): TrustedContactDao
    abstract fun callerRuleDao(): CallerRuleDao
    abstract fun callRecordDao(): CallRecordDao

    companion object {
        @Volatile
        private var INSTANCE: CallWiseDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE trusted_contacts ADD COLUMN accountType TEXT")
                db.execSQL("ALTER TABLE call_records ADD COLUMN direction TEXT NOT NULL DEFAULT 'INCOMING'")
                db.execSQL("ALTER TABLE call_records ADD COLUMN isUserConfirmedCategory INTEGER NOT NULL DEFAULT 0")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE call_records ADD COLUMN callSource TEXT NOT NULL DEFAULT 'SIM'")
                db.execSQL("ALTER TABLE call_records ADD COLUMN confidencePercent INTEGER NOT NULL DEFAULT 50")
            }
        }

        fun getInstance(context: Context): CallWiseDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CallWiseDatabase::class.java,
                    "callwise_local.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}

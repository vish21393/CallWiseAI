package com.callwise.ai.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.callwise.ai.domain.model.CallerCategory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "callwise_prefs")

data class UserPreferences(
    val enableExplicitSilenceRules: Boolean = false,
    val enableExplicitBlockRules: Boolean = false,
    val enabledPromoFlagCategories: Set<CallerCategory> = setOf(
        CallerCategory.PROMO_LOAN,
        CallerCategory.CREDIT_CARD_PROMO,
        CallerCategory.NEW_INSURANCE_SALES,
        CallerCategory.REAL_ESTATE_PROMO
    ),
    val floatingOverlayEnabled: Boolean = true,
    val localAiModelPath: String = "",
    val preferredLanguage: String = "English",
    val notifyPersonal: Boolean = true,
    val notifyProfessional: Boolean = true,
    val notifyBanking: Boolean = true,
    val notifyInsurance: Boolean = true,
    val notifyUnknownWarning: Boolean = true,
    val dailySummaryEnabled: Boolean = true,
    val dailySummaryHour: Int = 20,
    val dailySummaryMinute: Int = 0,
    val retentionDays: Int = 90,
    val lastContactSyncTime: Long = 0L,
    val lastContactCount: Int = 0
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val ENABLE_SILENCE_RULES = booleanPreferencesKey("enable_explicit_silence_rules")
        val ENABLE_BLOCK_RULES = booleanPreferencesKey("enable_explicit_block_rules")
        val PROMO_FLAG_CATEGORIES = stringSetPreferencesKey("enabled_promo_flag_categories")
        val FLOATING_OVERLAY_ENABLED = booleanPreferencesKey("floating_overlay_enabled")
        val LOCAL_AI_MODEL_PATH = stringPreferencesKey("local_ai_model_path")
        val PREFERRED_LANGUAGE = stringPreferencesKey("preferred_language")
        val NOTIFY_PERSONAL = booleanPreferencesKey("notify_personal")
        val NOTIFY_PROFESSIONAL = booleanPreferencesKey("notify_professional")
        val NOTIFY_BANKING = booleanPreferencesKey("notify_banking")
        val NOTIFY_INSURANCE = booleanPreferencesKey("notify_insurance")
        val NOTIFY_UNKNOWN_WARNING = booleanPreferencesKey("notify_unknown_warning")
        val DAILY_SUMMARY_ENABLED = booleanPreferencesKey("daily_summary_enabled")
        val DAILY_SUMMARY_HOUR = intPreferencesKey("daily_summary_hour")
        val DAILY_SUMMARY_MINUTE = intPreferencesKey("daily_summary_minute")
        val RETENTION_DAYS = intPreferencesKey("retention_days")
        val LAST_CONTACT_SYNC_TIME = longPreferencesKey("last_contact_sync_time")
        val LAST_CONTACT_COUNT = intPreferencesKey("last_contact_count")
    }

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        val defaultPromoSet = setOf(
            CallerCategory.PROMO_LOAN.name,
            CallerCategory.CREDIT_CARD_PROMO.name,
            CallerCategory.NEW_INSURANCE_SALES.name,
            CallerCategory.REAL_ESTATE_PROMO.name
        )
        val rawCategories = prefs[Keys.PROMO_FLAG_CATEGORIES] ?: defaultPromoSet
        val parsedCategories = rawCategories.mapNotNull { name ->
            runCatching { CallerCategory.valueOf(name) }.getOrNull()
        }.toSet()

        UserPreferences(
            enableExplicitSilenceRules = prefs[Keys.ENABLE_SILENCE_RULES] ?: false,
            enableExplicitBlockRules = prefs[Keys.ENABLE_BLOCK_RULES] ?: false,
            enabledPromoFlagCategories = parsedCategories,
            floatingOverlayEnabled = prefs[Keys.FLOATING_OVERLAY_ENABLED] ?: true,
            localAiModelPath = prefs[Keys.LOCAL_AI_MODEL_PATH].orEmpty(),
            preferredLanguage = prefs[Keys.PREFERRED_LANGUAGE] ?: "English",
            notifyPersonal = prefs[Keys.NOTIFY_PERSONAL] ?: true,
            notifyProfessional = prefs[Keys.NOTIFY_PROFESSIONAL] ?: true,
            notifyBanking = prefs[Keys.NOTIFY_BANKING] ?: true,
            notifyInsurance = prefs[Keys.NOTIFY_INSURANCE] ?: true,
            notifyUnknownWarning = prefs[Keys.NOTIFY_UNKNOWN_WARNING] ?: true,
            dailySummaryEnabled = prefs[Keys.DAILY_SUMMARY_ENABLED] ?: true,
            dailySummaryHour = prefs[Keys.DAILY_SUMMARY_HOUR] ?: 20,
            dailySummaryMinute = prefs[Keys.DAILY_SUMMARY_MINUTE] ?: 0,
            retentionDays = prefs[Keys.RETENTION_DAYS] ?: 90,
            lastContactSyncTime = prefs[Keys.LAST_CONTACT_SYNC_TIME] ?: 0L,
            lastContactCount = prefs[Keys.LAST_CONTACT_COUNT] ?: 0
        )
    }

    suspend fun getSnapshot(): UserPreferences = preferencesFlow.first()

    suspend fun setExplicitSilenceRules(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ENABLE_SILENCE_RULES] = enabled }
    }

    suspend fun setExplicitBlockRules(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ENABLE_BLOCK_RULES] = enabled }
    }

    suspend fun setFloatingOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.FLOATING_OVERLAY_ENABLED] = enabled }
    }

    suspend fun setLocalAiModelPath(path: String) {
        context.dataStore.edit { it[Keys.LOCAL_AI_MODEL_PATH] = path }
    }

    suspend fun setPreferredLanguage(language: String) {
        context.dataStore.edit { it[Keys.PREFERRED_LANGUAGE] = language }
    }

    suspend fun togglePromoFlagCategory(category: CallerCategory, enabled: Boolean) {
        context.dataStore.edit { prefs ->
            val current = (prefs[Keys.PROMO_FLAG_CATEGORIES] ?: setOf(
                CallerCategory.PROMO_LOAN.name,
                CallerCategory.CREDIT_CARD_PROMO.name,
                CallerCategory.NEW_INSURANCE_SALES.name,
                CallerCategory.REAL_ESTATE_PROMO.name
            )).toMutableSet()
            if (enabled) current.add(category.name) else current.remove(category.name)
            prefs[Keys.PROMO_FLAG_CATEGORIES] = current
        }
    }

    suspend fun setNotificationPreferences(
        personal: Boolean? = null,
        professional: Boolean? = null,
        banking: Boolean? = null,
        insurance: Boolean? = null,
        unknownWarning: Boolean? = null
    ) {
        context.dataStore.edit { prefs ->
            personal?.let { prefs[Keys.NOTIFY_PERSONAL] = it }
            professional?.let { prefs[Keys.NOTIFY_PROFESSIONAL] = it }
            banking?.let { prefs[Keys.NOTIFY_BANKING] = it }
            insurance?.let { prefs[Keys.NOTIFY_INSURANCE] = it }
            unknownWarning?.let { prefs[Keys.NOTIFY_UNKNOWN_WARNING] = it }
        }
    }

    suspend fun setDailySummarySchedule(enabled: Boolean, hour: Int, minute: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DAILY_SUMMARY_ENABLED] = enabled
            prefs[Keys.DAILY_SUMMARY_HOUR] = hour.coerceIn(0, 23)
            prefs[Keys.DAILY_SUMMARY_MINUTE] = minute.coerceIn(0, 59)
        }
    }

    suspend fun setRetentionDays(days: Int) {
        context.dataStore.edit { it[Keys.RETENTION_DAYS] = days }
    }

    suspend fun updateContactSyncMetadata(syncTimeMillis: Long, contactCount: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.LAST_CONTACT_SYNC_TIME] = syncTimeMillis
            prefs[Keys.LAST_CONTACT_COUNT] = contactCount
        }
    }
}

package com.callwise.ai.contacts

import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class ContactsChangeObserver(
    private val context: Context
) : ContentObserver(Handler(Looper.getMainLooper())) {

    private var isRegistered = false

    fun register() {
        if (isRegistered) return
        try {
            context.contentResolver.registerContentObserver(
                ContactsContract.Contacts.CONTENT_URI,
                true,
                this
            )
            isRegistered = true
        } catch (_: SecurityException) {
            // Permission not granted yet
        }
    }

    fun unregister() {
        if (!isRegistered) return
        runCatching {
            context.contentResolver.unregisterContentObserver(this)
        }
        isRegistered = false
    }

    override fun onChange(selfChange: Boolean, uri: Uri?) {
        super.onChange(selfChange, uri)
        val request = OneTimeWorkRequestBuilder<ContactsSyncWorker>()
            .setInitialDelay(2, TimeUnit.SECONDS)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            UNIQUE_SYNC_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    companion object {
        private const val UNIQUE_SYNC_WORK_NAME = "callwise_contacts_change_sync"
    }
}

package com.callwise.ai.screening

import android.content.Context
import android.telephony.TelephonyManager
import com.callwise.ai.data.local.CallRecordDao
import com.callwise.ai.data.local.CallRecordEntity
import com.callwise.ai.data.preferences.UserPreferencesRepository
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallSource
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.ContactTrustStatus
import com.callwise.ai.domain.model.SafetyRecommendation
import com.callwise.ai.domain.model.ScreeningAction
import com.callwise.ai.domain.model.ScreeningDecision
import com.callwise.ai.domain.util.PhoneNumberNormalizer
import com.callwise.ai.notifications.CallNotificationManager
import com.callwise.ai.overlay.CallOverlayService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicReference

class CallIntelligenceCoordinator(
    private val context: Context,
    private val classifier: RuleBasedCallerClassifier,
    private val callRecordDao: CallRecordDao,
    private val preferencesRepository: UserPreferencesRepository,
    private val notificationManager: CallNotificationManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private data class ActiveCallSession(
        val rawNumber: String,
        val normalizedNumber: String,
        val direction: CallDirection,
        val recordId: Long,
        val screenedAtMillis: Long,
        val answeredAtMillis: Long? = null,
        val lastTelephonyState: Int = TelephonyManager.CALL_STATE_IDLE
    )

    private val activeSession = AtomicReference<ActiveCallSession?>(null)
    private val dateFormatter = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())

    suspend fun onCallScreened(
        rawNumber: String?,
        callerDisplayName: String?,
        direction: CallDirection
    ) {
        onCallScreenedWithDecision(rawNumber, callerDisplayName, direction, null)
    }

    suspend fun onCallScreenedWithDecision(
        rawNumber: String?,
        callerDisplayName: String?,
        direction: CallDirection,
        precomputedDecision: ScreeningDecision?
    ) {
        val displayNumber = rawNumber?.takeIf { it.isNotBlank() } ?: "Private Number"
        val normalized = PhoneNumberNormalizer.normalize(rawNumber)
        val now = System.currentTimeMillis()
        val prefs = preferencesRepository.getSnapshot()

        val decision = precomputedDecision ?: runCatching {
            classifier.classify(
                rawNumber = rawNumber,
                callerDisplayName = callerDisplayName,
                preferences = prefs,
                direction = direction,
                callSource = CallSource.SIM
            )
        }.getOrElse {
            ScreeningDecision(
                callSource = CallSource.SIM,
                direction = direction,
                category = CallerCategory.UNKNOWN,
                callerName = callerDisplayName,
                isSavedContact = false,
                contactTrustStatus = ContactTrustStatus.UNKNOWN,
                recommendation = SafetyRecommendation.UNKNOWN_VERIFY_BEFORE_ANSWERING,
                confidencePercent = 30,
                isUserConfirmed = false,
                reason = "Lookup unavailable; advisory fallback."
            )
        }

        val initialStatus = when {
            decision.action == ScreeningAction.BLOCK_CALL -> CallStatus.BLOCKED_BY_RULE
            decision.action == ScreeningAction.SILENCE_CALL -> CallStatus.SILENCED_BY_RULE
            direction == CallDirection.OUTGOING -> CallStatus.OUTGOING_PLACED
            else -> CallStatus.ALLOWED_SCREENED
        }

        val recordId = runCatching {
            callRecordDao.insert(
                CallRecordEntity(
                    rawNumber = displayNumber,
                    normalizedNumber = normalized.normalized,
                    last10Digits = normalized.last10Digits,
                    callerName = decision.callerName,
                    timestamp = now,
                    durationSeconds = null,
                    status = initialStatus,
                    callSource = CallSource.SIM,
                    direction = direction,
                    category = decision.category,
                    confidencePercent = decision.confidencePercent,
                    isSavedContact = decision.isSavedContact,
                    isUserConfirmedCategory = decision.isUserConfirmed,
                    screeningReason = decision.reason
                )
            )
        }.getOrDefault(-1L)

        if (decision.action != ScreeningAction.BLOCK_CALL) {
            activeSession.set(
                ActiveCallSession(
                    rawNumber = displayNumber,
                    normalizedNumber = normalized.normalized,
                    direction = direction,
                    recordId = recordId,
                    screenedAtMillis = now,
                    answeredAtMillis = if (direction == CallDirection.OUTGOING) now else null,
                    lastTelephonyState = if (direction == CallDirection.OUTGOING) {
                        TelephonyManager.CALL_STATE_OFFHOOK
                    } else {
                        TelephonyManager.CALL_STATE_RINGING
                    }
                )
            )

            if (prefs.floatingOverlayEnabled) {
                val historySummary = buildHistorySummary(
                    normalized = normalized.normalized,
                    last10 = normalized.last10Digits,
                    excludeId = recordId
                )
                CallOverlayService.show(
                    context = context,
                    recordId = recordId,
                    rawNumber = displayNumber,
                    callerName = decision.callerName,
                    direction = direction,
                    trustStatus = decision.contactTrustStatus,
                    category = decision.category,
                    confidencePercent = decision.confidencePercent,
                    isUserConfirmed = decision.isUserConfirmed,
                    recommendation = decision.recommendation,
                    reason = decision.reason,
                    historySummary = historySummary.historyLines,
                    notesSummary = historySummary.latestNotes,
                    followUpSummary = historySummary.pendingFollowUp
                )
            }
        }

        if (direction == CallDirection.INCOMING && recordId > 0L && decision.action != ScreeningAction.BLOCK_CALL) {
            notificationManager.notifyScreenedCall(
                recordId = recordId,
                rawNumber = displayNumber,
                decision = decision,
                preferences = prefs
            )
        }
    }

    fun onTelephonyStateChanged(state: Int, incomingNumber: String?) {
        scope.launch {
            val current = activeSession.get()
            val now = System.currentTimeMillis()

            when (state) {
                TelephonyManager.CALL_STATE_RINGING -> {
                    val normIncoming = PhoneNumberNormalizer.normalize(incomingNumber)
                    val isSameRecent = current != null &&
                        (now - current.screenedAtMillis) < 4000L &&
                        (normIncoming.normalized.isEmpty() ||
                            PhoneNumberNormalizer.numbersMatch(current.rawNumber, incomingNumber))

                    if (!isSameRecent && !incomingNumber.isNullOrBlank()) {
                        onCallScreened(
                            rawNumber = incomingNumber,
                            callerDisplayName = null,
                            direction = CallDirection.INCOMING
                        )
                    }
                }

                TelephonyManager.CALL_STATE_OFFHOOK -> {
                    if (current != null) {
                        activeSession.set(
                            current.copy(
                                answeredAtMillis = current.answeredAtMillis ?: now,
                                lastTelephonyState = TelephonyManager.CALL_STATE_OFFHOOK
                            )
                        )
                        if (current.recordId > 0L && current.direction == CallDirection.INCOMING) {
                            runCatching {
                                callRecordDao.updateStatusAndDuration(current.recordId, CallStatus.ANSWERED, null)
                            }
                        }
                    } else if (!incomingNumber.isNullOrBlank()) {
                        onCallScreened(
                            rawNumber = incomingNumber,
                            callerDisplayName = null,
                            direction = CallDirection.OUTGOING
                        )
                    }
                }

                TelephonyManager.CALL_STATE_IDLE -> {
                    if (current != null && current.recordId > 0L) {
                        val answeredAt = current.answeredAtMillis
                        if (answeredAt != null) {
                            val durationSec = ((now - answeredAt) / 1000L).coerceAtLeast(0L)
                            val finalStatus = if (current.direction == CallDirection.OUTGOING) {
                                CallStatus.OUTGOING_PLACED
                            } else {
                                CallStatus.ANSWERED
                            }
                            runCatching {
                                callRecordDao.updateStatusAndDuration(current.recordId, finalStatus, durationSec)
                            }
                        } else if (current.direction == CallDirection.INCOMING) {
                            runCatching {
                                callRecordDao.updateStatusAndDuration(current.recordId, CallStatus.MISSED, null)
                            }
                        }
                    }
                    activeSession.set(null)
                    CallOverlayService.dismiss(context)
                }
            }
        }
    }

    private data class OverlayHistoryContext(
        val historyLines: String,
        val latestNotes: String?,
        val pendingFollowUp: String?
    )

    private suspend fun buildHistorySummary(
        normalized: String,
        last10: String,
        excludeId: Long
    ): OverlayHistoryContext {
        if (normalized.isEmpty()) {
            return OverlayHistoryContext("No previous local call history.", null, null)
        }
        val records = runCatching {
            callRecordDao.getRecentHistoryForNumber(normalized, last10, excludeId)
        }.getOrDefault(emptyList())

        if (records.isEmpty()) {
            return OverlayHistoryContext("No previous local call history.", null, null)
        }

        val lines = records.take(3).joinToString("\n") { rec ->
            val dateStr = dateFormatter.format(Date(rec.timestamp))
            "• [${rec.callSource.displayName}] ${rec.direction.displayName} (${rec.status.displayName}) – $dateStr"
        }

        val latestNotes = records.firstOrNull { !it.userNotes.isNullOrBlank() }?.userNotes
        val pendingFollowUpRecord = records.firstOrNull { it.followUpAt != null && !it.followUpDone }
        val pendingFollowUp = pendingFollowUpRecord?.let { rec ->
            val dueStr = rec.followUpAt?.let { dateFormatter.format(Date(it)) } ?: "Scheduled"
            val notePart = rec.userNotes?.takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()
            "Follow-up ($dueStr)$notePart"
        }

        return OverlayHistoryContext(lines, latestNotes, pendingFollowUp)
    }
}

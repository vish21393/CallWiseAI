package com.callwise.ai.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallSource
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.RuleType

@Entity(
    tableName = "trusted_contacts",
    indices = [
        Index(value = ["normalizedNumber"]),
        Index(value = ["last10Digits"]),
        Index(value = ["contactId"])
    ]
)
data class TrustedContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactId: Long,
    val displayName: String,
    val rawNumber: String,
    val normalizedNumber: String,
    val last10Digits: String,
    val label: String?,
    val accountType: String? = null,
    val updatedAt: Long
)

@Entity(tableName = "caller_rules")
data class CallerRuleEntity(
    @PrimaryKey val normalizedNumber: String,
    val last10Digits: String,
    val displayLabel: String?,
    val ruleType: RuleType,
    val category: CallerCategory,
    val notes: String? = null,
    val createdAt: Long
)

@Entity(
    tableName = "call_records",
    indices = [
        Index(value = ["normalizedNumber"]),
        Index(value = ["last10Digits"]),
        Index(value = ["timestamp"]),
        Index(value = ["category"])
    ]
)
data class CallRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val rawNumber: String,
    val normalizedNumber: String,
    val last10Digits: String,
    val callerName: String?,
    val timestamp: Long,
    val durationSeconds: Long? = null,
    val status: CallStatus,
    val callSource: CallSource = CallSource.SIM,
    val direction: CallDirection = CallDirection.INCOMING,
    val category: CallerCategory,
    val confidencePercent: Int = 50,
    val isSavedContact: Boolean,
    val isUserConfirmedCategory: Boolean = false,
    val screeningReason: String,
    val userNotes: String? = null,
    val followUpAt: Long? = null,
    val followUpDone: Boolean = false,
    val importedTranscript: String? = null,
    val localSummary: String? = null
)

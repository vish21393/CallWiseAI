package com.callwise.ai.screening

import com.callwise.ai.data.local.CallRecordDao
import com.callwise.ai.data.local.CallerRuleDao
import com.callwise.ai.data.local.TrustedContactDao
import com.callwise.ai.data.preferences.UserPreferences
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallSource
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.ContactTrustStatus
import com.callwise.ai.domain.model.RuleType
import com.callwise.ai.domain.model.SafetyRecommendation
import com.callwise.ai.domain.model.ScreeningAction
import com.callwise.ai.domain.model.ScreeningDecision
import com.callwise.ai.domain.util.PhoneNumberNormalizer

class RuleBasedCallerClassifier(
    private val trustedContactDao: TrustedContactDao,
    private val callerRuleDao: CallerRuleDao,
    private val callRecordDao: CallRecordDao
) {

    suspend fun classify(
        rawNumber: String?,
        callerDisplayName: String?,
        preferences: UserPreferences,
        direction: CallDirection = CallDirection.INCOMING,
        callSource: CallSource = CallSource.SIM
    ): ScreeningDecision {
        val normalized = PhoneNumberNormalizer.normalize(rawNumber)
        if (normalized.normalized.isEmpty()) {
            return ScreeningDecision(
                action = ScreeningAction.ADVISORY_ALLOW,
                callSource = callSource,
                direction = direction,
                category = CallerCategory.UNKNOWN,
                callerName = callerDisplayName?.takeIf { it.isNotBlank() },
                isSavedContact = false,
                contactTrustStatus = ContactTrustStatus.UNKNOWN,
                recommendation = SafetyRecommendation.UNKNOWN_VERIFY_BEFORE_ANSWERING,
                confidencePercent = 30,
                isUserConfirmed = false,
                reason = "Private or unavailable number; advisory only."
            )
        }

        // 1. Saved-contact protection ALWAYS overrides every rule
        val savedContact = runCatching {
            trustedContactDao.findMatch(normalized.normalized, normalized.last10Digits)
        }.getOrNull()

        if (savedContact != null) {
            val isGoogleSynced = savedContact.accountType?.contains("google", ignoreCase = true) == true
            val trustStatus = if (isGoogleSynced) {
                ContactTrustStatus.GOOGLE_SYNCED_CONTACT
            } else {
                ContactTrustStatus.SAVED_PHONE_CONTACT
            }
            return ScreeningDecision(
                action = ScreeningAction.ADVISORY_ALLOW,
                callSource = callSource,
                direction = direction,
                category = CallerCategory.PERSONAL_TRUSTED,
                callerName = savedContact.displayName,
                isSavedContact = true,
                contactTrustStatus = trustStatus,
                recommendation = SafetyRecommendation.SAVED_CONTACT_TRUSTED,
                confidencePercent = 98,
                isUserConfirmed = true,
                reason = "${trustStatus.displayName} (${savedContact.displayName})."
            )
        }

        // 2. User-configured Allow / Silence / Block rules
        val manualRule = runCatching {
            callerRuleDao.findRule(normalized.normalized, normalized.last10Digits)
        }.getOrNull()

        if (manualRule != null) {
            val action = when (manualRule.ruleType) {
                RuleType.ALLOWLIST -> ScreeningAction.ADVISORY_ALLOW
                RuleType.SILENCELIST -> {
                    if (direction == CallDirection.INCOMING && preferences.enableExplicitSilenceRules) {
                        ScreeningAction.SILENCE_CALL
                    } else {
                        ScreeningAction.ADVISORY_ALLOW
                    }
                }
                RuleType.BLOCKLIST -> {
                    if (direction == CallDirection.INCOMING && preferences.enableExplicitBlockRules) {
                        ScreeningAction.BLOCK_CALL
                    } else {
                        ScreeningAction.ADVISORY_ALLOW
                    }
                }
            }

            val (trustStatus, recommendation, reason) = when (manualRule.ruleType) {
                RuleType.ALLOWLIST -> Triple(
                    ContactTrustStatus.MANUALLY_TRUSTED,
                    SafetyRecommendation.KNOWN_CALLER_REVIEW_HISTORY,
                    "User-confirmed Allow rule."
                )
                RuleType.SILENCELIST -> Triple(
                    ContactTrustStatus.UNKNOWN,
                    SafetyRecommendation.POSSIBLE_PROMOTIONAL_CALL,
                    if (action == ScreeningAction.SILENCE_CALL) {
                        "Silenced by explicit user Silence rule."
                    } else {
                        "User Silence rule (advisory; auto-silence disabled)."
                    }
                )
                RuleType.BLOCKLIST -> Triple(
                    ContactTrustStatus.UNKNOWN,
                    SafetyRecommendation.SUSPECTED_SPAM_BE_CAUTIOUS,
                    if (action == ScreeningAction.BLOCK_CALL) {
                        "Blocked by explicit user Block rule."
                    } else {
                        "User Block rule (advisory; auto-block disabled)."
                    }
                )
            }

            return ScreeningDecision(
                action = action,
                callSource = callSource,
                direction = direction,
                category = manualRule.category,
                callerName = manualRule.displayLabel ?: callerDisplayName,
                isSavedContact = false,
                contactTrustStatus = trustStatus,
                recommendation = recommendation,
                confidencePercent = 95,
                isUserConfirmed = true,
                reason = reason
            )
        }

        // 3. Prior local history category
        val priorRecord = runCatching {
            callRecordDao.getLatestForNumber(normalized.normalized, normalized.last10Digits)
        }.getOrNull()

        val (inferredCategory, isUserConfirmed, confidence) = classifyByLocalHeuristics(
            normalizedDigits = normalized.normalized,
            last10 = normalized.last10Digits,
            callerDisplayName = callerDisplayName,
            priorCategory = priorRecord?.category,
            priorConfirmed = priorRecord?.isUserConfirmedCategory ?: false
        )

        val resolvedName = callerDisplayName?.takeIf { it.isNotBlank() } ?: priorRecord?.callerName

        val recommendation = when {
            inferredCategory == CallerCategory.SUSPECTED_SPAM ->
                SafetyRecommendation.SUSPECTED_SPAM_BE_CAUTIOUS
            inferredCategory.isPromotional ->
                SafetyRecommendation.POSSIBLE_PROMOTIONAL_CALL
            priorRecord != null ->
                SafetyRecommendation.KNOWN_CALLER_REVIEW_HISTORY
            else ->
                SafetyRecommendation.UNKNOWN_VERIFY_BEFORE_ANSWERING
        }

        val sourceLabel = if (isUserConfirmed) "User-confirmed" else "Locally suspected"
        val reason = if (inferredCategory == CallerCategory.UNKNOWN) {
            "Not in contacts; verify before answering."
        } else {
            "$sourceLabel as ${inferredCategory.displayName}."
        }

        return ScreeningDecision(
            action = ScreeningAction.ADVISORY_ALLOW,
            callSource = callSource,
            direction = direction,
            category = inferredCategory,
            callerName = resolvedName,
            isSavedContact = false,
            contactTrustStatus = ContactTrustStatus.UNKNOWN,
            recommendation = recommendation,
            confidencePercent = confidence,
            isUserConfirmed = isUserConfirmed,
            reason = reason
        )
    }

    internal fun classifyByLocalHeuristics(
        normalizedDigits: String,
        last10: String,
        callerDisplayName: String?,
        priorCategory: CallerCategory?,
        priorConfirmed: Boolean = false
    ): Triple<CallerCategory, Boolean, Int> {
        if (priorConfirmed && priorCategory != null && priorCategory != CallerCategory.UNKNOWN) {
            return Triple(priorCategory, true, 92)
        }

        val nameLower = callerDisplayName?.lowercase().orEmpty()
        if (nameLower.isNotBlank()) {
            when {
                containsAny(nameLower, "loan", "emi", "personal loan", "instant cash", "credit line") ->
                    return Triple(CallerCategory.PROMO_LOAN, false, 78)
                containsAny(nameLower, "credit card", "card offer", "rupay", "visa upgrade") ->
                    return Triple(CallerCategory.CREDIT_CARD_PROMO, false, 78)
                containsAny(nameLower, "real estate", "property", "villas", "apartments", "plots", "realty") ->
                    return Triple(CallerCategory.REAL_ESTATE_PROMO, false, 76)
                containsAny(nameLower, "insurance policy", "term plan", "new policy", "lic agent") ->
                    return Triple(CallerCategory.NEW_INSURANCE_SALES, false, 76)
                containsAny(nameLower, "claim", "policy service", "renewal", "insurance") ->
                    return Triple(CallerCategory.INSURANCE_SERVICING, false, 75)
                containsAny(nameLower, "bank", "hdfc", "icici", "sbi", "axis", "kotak", "upi", "branch") ->
                    return Triple(CallerCategory.BANK_FINANCIAL, false, 80)
                containsAny(nameLower, "hr", "recruit", "talent", "hiring", "interview", "careers") ->
                    return Triple(CallerCategory.PROFESSIONAL_RECRUITER, false, 80)
            }
        }

        if (priorCategory != null && priorCategory != CallerCategory.UNKNOWN) {
            return Triple(priorCategory, priorConfirmed, 70)
        }

        val cleanDigits = normalizedDigits.removePrefix("+")
        if (cleanDigits.startsWith("140") || cleanDigits.startsWith("91140") || last10.startsWith("140")) {
            return Triple(CallerCategory.SUSPECTED_SPAM, false, 68)
        }

        return Triple(CallerCategory.UNKNOWN, false, 40)
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { text.contains(it) }
    }
}

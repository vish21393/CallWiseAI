package com.callwise.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.RuleType
import kotlinx.coroutines.flow.Flow

@Dao
interface TrustedContactDao {

    @Query(
        """
        SELECT * FROM trusted_contacts
        WHERE normalizedNumber = :normalized
           OR (:last10 != '' AND LENGTH(:last10) >= 7 AND last10Digits = :last10)
        LIMIT 1
        """
    )
    suspend fun findMatch(normalized: String, last10: String): TrustedContactEntity?

    @Query("SELECT * FROM trusted_contacts ORDER BY displayName ASC")
    fun observeAll(): Flow<List<TrustedContactEntity>>

    @Query("SELECT COUNT(DISTINCT contactId) FROM trusted_contacts")
    fun observeDistinctContactCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM trusted_contacts")
    suspend fun getNumberCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(contacts: List<TrustedContactEntity>)

    @Query("DELETE FROM trusted_contacts")
    suspend fun deleteAll()

    @Transaction
    suspend fun replaceAll(contacts: List<TrustedContactEntity>) {
        deleteAll()
        if (contacts.isNotEmpty()) {
            insertAll(contacts)
        }
    }
}

@Dao
interface CallerRuleDao {

    @Query(
        """
        SELECT * FROM caller_rules
        WHERE normalizedNumber = :normalized
           OR (:last10 != '' AND LENGTH(:last10) >= 7 AND last10Digits = :last10)
        LIMIT 1
        """
    )
    suspend fun findRule(normalized: String, last10: String): CallerRuleEntity?

    @Query("SELECT * FROM caller_rules ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<CallerRuleEntity>>

    @Query("SELECT * FROM caller_rules WHERE ruleType = :type ORDER BY createdAt DESC")
    fun observeByType(type: RuleType): Flow<List<CallerRuleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: CallerRuleEntity)

    @Query("DELETE FROM caller_rules WHERE normalizedNumber = :normalized")
    suspend fun deleteByNumber(normalizedNumber: String)

    @Query("DELETE FROM caller_rules")
    suspend fun deleteAll()
}

@Dao
interface CallRecordDao {

    @Query("SELECT * FROM call_records ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<CallRecordEntity>>

    @Query("SELECT * FROM call_records WHERE id = :id")
    fun observeById(id: Long): Flow<CallRecordEntity?>

    @Query("SELECT * FROM call_records WHERE id = :id")
    suspend fun getById(id: Long): CallRecordEntity?

    @Query(
        """
        SELECT * FROM call_records
        WHERE normalizedNumber = :normalized
           OR (:last10 != '' AND LENGTH(:last10) >= 7 AND last10Digits = :last10)
        ORDER BY timestamp DESC
        """
    )
    fun observeHistoryForNumber(normalized: String, last10: String): Flow<List<CallRecordEntity>>

    @Query(
        """
        SELECT * FROM call_records
        WHERE (normalizedNumber = :normalized
           OR (:last10 != '' AND LENGTH(:last10) >= 7 AND last10Digits = :last10))
          AND id != :excludeId
        ORDER BY timestamp DESC
        LIMIT 5
        """
    )
    suspend fun getRecentHistoryForNumber(
        normalized: String,
        last10: String,
        excludeId: Long = -1L
    ): List<CallRecordEntity>

    @Query(
        """
        SELECT * FROM call_records
        WHERE normalizedNumber = :normalized
           OR (:last10 != '' AND LENGTH(:last10) >= 7 AND last10Digits = :last10)
        ORDER BY timestamp DESC
        LIMIT 1
        """
    )
    suspend fun getLatestForNumber(normalized: String, last10: String): CallRecordEntity?

    @Query(
        """
        SELECT * FROM call_records
        WHERE (userNotes LIKE '%' || :query || '%'
           OR localSummary LIKE '%' || :query || '%'
           OR importedTranscript LIKE '%' || :query || '%'
           OR callerName LIKE '%' || :query || '%')
        ORDER BY timestamp DESC
        LIMIT 30
        """
    )
    suspend fun searchNotesAndSummaries(query: String): List<CallRecordEntity>

    @Query("SELECT * FROM call_records WHERE timestamp >= :startOfDayMillis ORDER BY timestamp DESC")
    fun observeSince(startOfDayMillis: Long): Flow<List<CallRecordEntity>>

    @Query("SELECT * FROM call_records WHERE timestamp >= :startOfDayMillis ORDER BY timestamp DESC")
    suspend fun getSince(startOfDayMillis: Long): List<CallRecordEntity>

    @Query(
        """
        SELECT * FROM call_records
        WHERE followUpAt IS NOT NULL AND followUpDone = 0
        ORDER BY followUpAt ASC
        """
    )
    fun observePendingFollowUps(): Flow<List<CallRecordEntity>>

    @Query(
        """
        SELECT * FROM call_records
        WHERE followUpAt IS NOT NULL AND followUpDone = 0
        ORDER BY followUpAt ASC
        """
    )
    suspend fun getPendingFollowUps(): List<CallRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: CallRecordEntity): Long

    @Update
    suspend fun update(record: CallRecordEntity)

    @Query("UPDATE call_records SET category = :category, isUserConfirmedCategory = :confirmed WHERE id = :id")
    suspend fun updateCategory(id: Long, category: CallerCategory, confirmed: Boolean = true)

    @Query("UPDATE call_records SET status = :status, durationSeconds = :durationSeconds WHERE id = :id")
    suspend fun updateStatusAndDuration(id: Long, status: CallStatus, durationSeconds: Long?)

    @Query("UPDATE call_records SET userNotes = :notes WHERE id = :id")
    suspend fun updateNotes(id: Long, notes: String?)

    @Query("UPDATE call_records SET followUpAt = :followUpAt, followUpDone = :done WHERE id = :id")
    suspend fun updateFollowUp(id: Long, followUpAt: Long?, done: Boolean)

    @Query("UPDATE call_records SET importedTranscript = :transcript, localSummary = :summary WHERE id = :id")
    suspend fun updateTranscriptAndSummary(id: Long, transcript: String?, summary: String?)

    @Query("DELETE FROM call_records WHERE timestamp < :cutoffMillis")
    suspend fun deleteOlderThan(cutoffMillis: Long): Int

    @Query("DELETE FROM call_records")
    suspend fun deleteAll()
}

# Changelog – CallWise AI

## v1.3.0
- **Three-Module Gradle Architecture**:
  - `:core:common`: Shared domain models (`CallSource.SIM` vs `CallSource.VOIP`, `RuleType.ALLOWLIST/SILENCELIST/BLOCKLIST`, `confidencePercent`) and `PhoneNumberNormalizer`.
  - `:module:sim-assistant`: Isolated SIM Call Assistant (NO `INTERNET`, NO `RECORD_AUDIO`), Room v3 (`MIGRATION_2_3`), advisory-by-default `CallWiseScreeningService` with opt-in explicit `SILENCE`/`BLOCK` rules, and upgraded `CallOverlayService` with confidence % and quick-tag actions (`Important`, `Trusted`, `Spam`, `Follow-up`).
  - `:module:offline-ai`: 100% offline personal intelligence engine supporting English, Hindi, and Telugu (`MultilingualLocalAiEngine`), commitment/deadline/action-item extraction, note search, optional local model path verification, and live on-device benchmark runner tailored for Vivo X100 Pro (16 GB RAM).
  - `:module:voip-receptionist`: Isolated experimental VoIP AI Receptionist Lab (the only module declaring `INTERNET` and `RECORD_AUDIO`), featuring Local Loopback Test Mode, SIP endpoint configuration, offline TTS + `AudioRecord` barge-in interruption, live transcript, intent detection, post-call summary, and User Takeover.
- **3-Section Compose UI**: Updated navigation to clearly separate `SIM`, `Offline AI`, and `VoIP Lab`, plus `History` (with SIM/VoIP filters) and `Settings`.

## v1.2.0
- Strictly advisory two-way SIM call detection (`CallScreeningService` + `TelephonyCallback` + `PhoneStateReceiver`), expandable/minimisable overlay, and Room v1->v2 migration.

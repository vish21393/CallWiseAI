# CallWise AI – Personal Call Intelligence (v1.3)

> **Know who's calling. Protect your time. Remember what matters.**

CallWise AI v1.3 is a privacy-first, modular Android application built in **Kotlin** and **Jetpack Compose**, designed for mobile-first GitHub Actions builds and high-RAM flagship devices such as the **Vivo X100 Pro (16 GB RAM / 512 GB)**.

---

## 1. Three Independent Modules

1. **Module A — SIM Call Assistant (`:module:sim-assistant`)**
   - Keeps **Google Phone** as the default dialer.
   - **Zero `INTERNET` and zero `RECORD_AUDIO` permissions.**
   - `CallScreeningService` + `TelephonyCallback` + `PHONE_STATE` + `SYSTEM_ALERT_WINDOW` floating card.
   - **Advisory by default**: never rejects or silences calls unless you explicitly create a rule and enable Silence/Block enforcement in Settings. Saved contacts always override every rule.
2. **Module B — Offline AI Personal Intelligence (`:module:offline-ai`)**
   - **Zero `INTERNET` permission.**
   - Built-in multilingual extractive engine (**English, Hindi, Telugu**) for summarising user-supplied transcripts/notes, extracting commitments, dates/deadlines, action items, and caller intent.
   - Includes a **Vivo X100 Pro Model Catalog** (`Qwen 2.5 3B`, `Gemma 2 2B`, `Llama 3.2 3B`, `Whisper Small / Sherpa-ONNX`, `Piper / Android Offline TTS`) and a live on-device **Benchmark Runner** measuring load/inspect time, inference latency, and JVM/Native heap usage.
3. **Module C — AI Receptionist Lab (`:module:voip-receptionist`)**
   - Isolated experimental **VoIP-only** module (the only module declaring `INTERNET` and `RECORD_AUDIO`).
   - Clearly labeled `[VoIP]` everywhere—never represents itself as a SIM cellular AI receptionist.
   - Includes **Local Loopback Test Mode** (works offline without a paid SIP provider), configurable SIP endpoint, offline `TextToSpeech` + `AudioRecord` **barge-in interruption**, live transcript, **User Takeover**, and post-call summary.

---

## 2. Honest Android & Vivo X100 Pro Limitations

- **No Two-Way SIM Cellular AI Audio**: Public Android APIs do not grant third-party apps access to uplink/downlink cellular SIM voice streams. Autonomous two-way AI voice conversation is strictly isolated to **Module C (VoIP Lab)**.
- **Vivo FuntouchOS / OriginOS Overlay & Background Rules**: To keep the floating SIM card visible on the lock screen and auto-dismiss reliably on `IDLE`, enable **"Display over other apps"**, **"Show on Lock screen"**, and set battery usage to **Unrestricted** in Vivo App Info.

---

## 3. GitHub Actions APK Build

1. Push the contents of `CallWiseAI/` to your GitHub repository's `main` branch.
2. GitHub Actions (`.github/workflows/android-debug-apk.yml`) runs `gradle testDebugUnitTest assembleDebug --no-daemon`.
3. Download **CallWiseAI-debug-apk** from the completed workflow run and install `app-debug.apk` on your Vivo X100 Pro.

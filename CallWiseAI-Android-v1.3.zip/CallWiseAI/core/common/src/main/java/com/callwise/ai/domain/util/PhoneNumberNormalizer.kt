package com.callwise.ai.domain.util

import com.callwise.ai.domain.model.NormalizedPhone

object PhoneNumberNormalizer {

    fun normalize(rawNumber: String?): NormalizedPhone {
        if (rawNumber.isNullOrBlank()) {
            return NormalizedPhone(raw = "", normalized = "", last10Digits = "")
        }

        val trimmed = rawNumber.trim()
        val hasLeadingPlus = trimmed.startsWith("+")
        val digitsOnly = buildString {
            for (ch in trimmed) {
                if (ch.isDigit()) append(ch)
            }
        }

        if (digitsOnly.isEmpty()) {
            return NormalizedPhone(raw = trimmed, normalized = "", last10Digits = "")
        }

        val canonicalDigits = when {
            digitsOnly.startsWith("00") && digitsOnly.length > 4 -> digitsOnly.drop(2)
            else -> digitsOnly
        }

        val normalized = when {
            hasLeadingPlus || digitsOnly.startsWith("00") -> "+$canonicalDigits"
            canonicalDigits.length > 10 && canonicalDigits.startsWith("0") -> {
                canonicalDigits.trimStart('0').ifEmpty { canonicalDigits }
            }
            else -> canonicalDigits
        }

        val last10 = if (canonicalDigits.length >= 10) {
            canonicalDigits.takeLast(10)
        } else {
            canonicalDigits
        }

        return NormalizedPhone(
            raw = trimmed,
            normalized = normalized,
            last10Digits = last10
        )
    }

    fun numbersMatch(first: String?, second: String?): Boolean {
        val a = normalize(first)
        val b = normalize(second)
        if (a.normalized.isEmpty() || b.normalized.isEmpty()) return false
        if (a.normalized == b.normalized) return true
        return a.last10Digits.length >= 7 && a.last10Digits == b.last10Digits
    }
}

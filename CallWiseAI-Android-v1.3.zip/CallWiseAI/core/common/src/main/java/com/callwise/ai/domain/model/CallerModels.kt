package com.callwise.ai.domain.model

enum class CallSource(val displayName: String) {
    SIM("SIM"),
    VOIP("VoIP")
}

enum class CallerCategory(
    val displayName: String,
    val isImportant: Boolean,
    val isPromotional: Boolean
) {
    PERSONAL_TRUSTED("Personal / Trusted", isImportant = true, isPromotional = false),
    PROFESSIONAL_RECRUITER("Professional / Recruiter", isImportant = true, isPromotional = false),
    BANK_FINANCIAL("Bank & Financial Services", isImportant = true, isPromotional = false),
    INSURANCE_SERVICING("Insurance Servicing", isImportant = true, isPromotional = false),
    PROMO_LOAN("Promotional Loan Offers", isImportant = false, isPromotional = true),
    CREDIT_CARD_PROMO("Credit Card Promotions", isImportant = false, isPromotional = true),
    NEW_INSURANCE_SALES("New Insurance Sales", isImportant = false, isPromotional = true),
    REAL_ESTATE_PROMO("Real Estate Promotions", isImportant = false, isPromotional = true),
    SUSPECTED_SPAM("Suspicious / Suspected Spam", isImportant = false, isPromotional = false),
    UNKNOWN("Unknown Caller", isImportant = false, isPromotional = false)
}

enum class CallDirection(val displayName: String) {
    INCOMING("Incoming"),
    OUTGOING("Outgoing")
}

enum class CallStatus(val displayName: String) {
    ALLOWED_SCREENED("Screened (Advisory)"),
    SILENCED_BY_RULE("Silenced by Rule"),
    BLOCKED_BY_RULE("Blocked by Rule"),
    ANSWERED("Answered"),
    MISSED("Missed"),
    REJECTED("Rejected by User"),
    OUTGOING_PLACED("Outgoing")
}

enum class RuleType(val displayName: String) {
    ALLOWLIST("Allow"),
    SILENCELIST("Silence"),
    BLOCKLIST("Block")
}

enum class ContactTrustStatus(val displayName: String) {
    SAVED_PHONE_CONTACT("Saved Phone Contact"),
    GOOGLE_SYNCED_CONTACT("Google-Synced Contact"),
    MANUALLY_TRUSTED("Manually Trusted"),
    UNKNOWN("Unknown Number")
}

enum class SafetyRecommendation(val label: String) {
    SAVED_CONTACT_TRUSTED("Saved Contact – Trusted"),
    KNOWN_CALLER_REVIEW_HISTORY("Known Caller – Review History"),
    UNKNOWN_VERIFY_BEFORE_ANSWERING("Unknown Caller – Verify Before Answering"),
    POSSIBLE_PROMOTIONAL_CALL("Possible Promotional Call"),
    SUSPECTED_SPAM_BE_CAUTIOUS("Suspected Spam – Be Cautious")
}

data class NormalizedPhone(
    val raw: String,
    val normalized: String,
    val last10Digits: String
)

enum class ScreeningAction {
    ADVISORY_ALLOW,
    SILENCE_CALL,
    BLOCK_CALL
}

data class ScreeningDecision(
    val action: ScreeningAction = ScreeningAction.ADVISORY_ALLOW,
    val callSource: CallSource = CallSource.SIM,
    val direction: CallDirection = CallDirection.INCOMING,
    val category: CallerCategory,
    val callerName: String?,
    val isSavedContact: Boolean,
    val contactTrustStatus: ContactTrustStatus,
    val recommendation: SafetyRecommendation,
    val confidencePercent: Int,
    val isUserConfirmed: Boolean,
    val reason: String
)

package com.callwise.ai.domain.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneNumberNormalizerTest {

    @Test
    fun `normalizes international and local Indian numbers consistently`() {
        val intl = PhoneNumberNormalizer.normalize("+91 98765-43210")
        val trunk = PhoneNumberNormalizer.normalize("09876543210")
        val doubleZero = PhoneNumberNormalizer.normalize("0091 98765 43210")

        assertEquals("+919876543210", intl.normalized)
        assertEquals("9876543210", intl.last10Digits)
        assertEquals("9876543210", trunk.last10Digits)
        assertEquals("+919876543210", doubleZero.normalized)
        assertTrue(PhoneNumberNormalizer.numbersMatch("+91 98765-43210", "09876543210"))
    }

    @Test
    fun `handles blank and non-numeric inputs safely`() {
        assertEquals("", PhoneNumberNormalizer.normalize("   ").normalized)
        assertEquals("", PhoneNumberNormalizer.normalize("Private").normalized)
        assertFalse(PhoneNumberNormalizer.numbersMatch("", "9876543210"))
    }
}

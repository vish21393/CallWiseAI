# CallWise AI ProGuard Rules
-keepclassmembers class * extends androidx.room.RoomDatabase {
    public *;
}
-dontwarn javax.annotation.**

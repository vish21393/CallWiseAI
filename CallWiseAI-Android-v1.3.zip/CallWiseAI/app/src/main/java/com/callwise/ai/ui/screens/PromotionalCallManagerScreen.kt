package com.callwise.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.RuleType
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.SectionHeader

@Composable
fun PromotionalCallManagerScreen(viewModel: CallWiseViewModel) {
    val prefs by viewModel.preferences.collectAsState()
    val rules by viewModel.callerRules.collectAsState()

    var newNumber by remember { mutableStateOf("") }
    var newLabel by remember { mutableStateOf("") }

    val promoCategories = remember { CallerCategory.entries.filter { it.isPromotional } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Call Rules & Promotional Manager",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Advisory by default. Explicit Silence or Block rules only apply when enabled in Settings. Saved contacts always override.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item { SectionHeader(title = "Promotional Flag Categories") }

        items(promoCategories, key = { it.name }) { category ->
            val enabled = prefs.enabledPromoFlagCategories.contains(category)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(category.displayName, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Switch(checked = enabled, onCheckedChange = { viewModel.togglePromoFlagCategory(category, it) })
                }
            }
        }

        item {
            SectionHeader(title = "Add Allow / Silence / Block Rule")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newNumber,
                        onValueChange = { newNumber = it },
                        label = { Text("Phone number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newLabel,
                        onValueChange = { newLabel = it },
                        label = { Text("Label (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = {
                                viewModel.addOrUpdateRule(newNumber, newLabel, RuleType.ALLOWLIST, CallerCategory.PERSONAL_TRUSTED)
                                newNumber = ""
                                newLabel = ""
                            },
                            enabled = newNumber.isNotBlank()
                        ) { Text("Allow") }
                        OutlinedButton(
                            onClick = {
                                viewModel.addOrUpdateRule(newNumber, newLabel, RuleType.SILENCELIST, CallerCategory.PROMO_LOAN)
                                newNumber = ""
                                newLabel = ""
                            },
                            enabled = newNumber.isNotBlank()
                        ) { Text("Silence") }
                        OutlinedButton(
                            onClick = {
                                viewModel.addOrUpdateRule(newNumber, newLabel, RuleType.BLOCKLIST, CallerCategory.SUSPECTED_SPAM)
                                newNumber = ""
                                newLabel = ""
                            },
                            enabled = newNumber.isNotBlank()
                        ) { Text("Block") }
                    }
                }
            }
        }

        items(rules, key = { "rule_${it.normalizedNumber}" }) { rule ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(rule.displayLabel ?: rule.normalizedNumber, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${rule.normalizedNumber} • ${rule.ruleType.displayName} Rule",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = { viewModel.deleteRule(rule.normalizedNumber) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete rule")
                    }
                }
            }
        }
    }
}

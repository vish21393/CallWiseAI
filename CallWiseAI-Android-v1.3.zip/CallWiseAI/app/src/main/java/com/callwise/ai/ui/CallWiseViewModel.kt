package com.callwise.ai.ui

import android.app.role.RoleManager
import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.callwise.ai.AppContainer
import com.callwise.ai.ai.AiLanguage
import com.callwise.ai.ai.BenchmarkResult
import com.callwise.ai.ai.CallIntelligenceOutput
import com.callwise.ai.ai.LocalModelStatus
import com.callwise.ai.ai.ModelCatalogAndBenchmarks
import com.callwise.ai.contacts.SyncState
import com.callwise.ai.data.local.CallRecordEntity
import com.callwise.ai.data.local.CallerRuleEntity
import com.callwise.ai.data.local.TrustedContactEntity
import com.callwise.ai.data.preferences.UserPreferences
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallSource
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.RuleType
import com.callwise.ai.domain.model.ScreeningDecision
import com.callwise.ai.domain.util.PhoneNumberNormalizer
import com.callwise.ai.notifications.DailySummaryScheduler
import com.callwise.ai.voip.SipProfile
import com.callwise.ai.voip.VoipSessionSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class DailyMetrics(
    val totalToday: Int = 0,
    val importantToday: Int = 0,
    val flaggedToday: Int = 0,
    val missedToday: Int = 0
)

class CallWiseViewModel(
    private val appContext: Context,
    private val container: AppContainer
) : ViewModel() {

    private val sim = container.simContainer

    val preferences: StateFlow<UserPreferences> = sim.preferencesRepository.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    val syncState: StateFlow<SyncState> = sim.contactsSyncManager.syncState

    val contacts: StateFlow<List<TrustedContactEntity>> = sim.trustedContactDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val distinctContactCount: StateFlow<Int> = sim.trustedContactDao.observeDistinctContactCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val callRecords: StateFlow<List<CallRecordEntity>> = sim.callRecordDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingFollowUps: StateFlow<List<CallRecordEntity>> = sim.callRecordDao.observePendingFollowUps()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val callerRules: StateFlow<List<CallerRuleEntity>> = sim.callerRuleDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dailyMetrics: StateFlow<DailyMetrics> = callRecords.map { records ->
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val today = records.filter { it.timestamp >= startOfDay }
        DailyMetrics(
            totalToday = today.size,
            importantToday = today.count { it.category.isImportant },
            flaggedToday = today.count { it.category.isPromotional || it.category == CallerCategory.SUSPECTED_SPAM },
            missedToday = today.count { it.status == CallStatus.MISSED }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DailyMetrics())

    // Module A simulator
    private val _simulatedScreeningResult = MutableStateFlow<ScreeningDecision?>(null)
    val simulatedScreeningResult: StateFlow<ScreeningDecision?> = _simulatedScreeningResult.asStateFlow()

    // Module B: Offline AI Intelligence state
    private val _aiAnalysisResult = MutableStateFlow<CallIntelligenceOutput?>(null)
    val aiAnalysisResult: StateFlow<CallIntelligenceOutput?> = _aiAnalysisResult.asStateFlow()

    private val _noteSearchResults = MutableStateFlow<List<CallRecordEntity>>(emptyList())
    val noteSearchResults: StateFlow<List<CallRecordEntity>> = _noteSearchResults.asStateFlow()

    private val _modelStatus = MutableStateFlow<LocalModelStatus?>(null)
    val modelStatus: StateFlow<LocalModelStatus?> = _modelStatus.asStateFlow()

    private val _benchmarkResult = MutableStateFlow<BenchmarkResult?>(null)
    val benchmarkResult: StateFlow<BenchmarkResult?> = _benchmarkResult.asStateFlow()

    // Module C: VoIP Receptionist Lab state
    val voipSession: StateFlow<VoipSessionSnapshot> = container.voipReceptionistManager.session
    val sipProfile: StateFlow<SipProfile> = container.voipReceptionistManager.sipProfile

    // Permissions
    fun hasContactsPermission(): Boolean = sim.contactsSyncManager.hasContactsPermission()
    fun hasNotificationPermission(): Boolean = sim.notificationManager.hasNotificationPermission()
    fun hasOverlayPermission(): Boolean = Settings.canDrawOverlays(appContext)
    fun hasPhoneStatePermission(): Boolean = sim.callStateMonitor.hasPhoneStatePermission()
    fun hasVoipAudioPermission(): Boolean = container.voipReceptionistManager.hasAudioPermission()

    fun registerCallStateMonitor() {
        sim.callStateMonitor.register()
    }

    fun isCallScreeningRoleHeld(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = appContext.getSystemService(RoleManager::class.java)
            roleManager?.isRoleHeld(RoleManager.ROLE_CALL_SCREENING) == true
        } else {
            false
        }
    }

    fun syncContactsNow() {
        viewModelScope.launch {
            sim.contactsChangeObserver.register()
            sim.contactsSyncManager.syncContacts()
        }
    }

    fun observeCallRecord(id: Long): Flow<CallRecordEntity?> = sim.callRecordDao.observeById(id)

    fun observeHistoryForNumber(rawNumber: String): Flow<List<CallRecordEntity>> {
        val norm = PhoneNumberNormalizer.normalize(rawNumber)
        return sim.callRecordDao.observeHistoryForNumber(norm.normalized, norm.last10Digits)
    }

    fun updateCategory(recordId: Long, category: CallerCategory) {
        viewModelScope.launch { sim.callRecordDao.updateCategory(recordId, category, confirmed = true) }
    }

    fun updateStatusAndDuration(recordId: Long, status: CallStatus, durationSeconds: Long?) {
        viewModelScope.launch { sim.callRecordDao.updateStatusAndDuration(recordId, status, durationSeconds) }
    }

    fun updateNotes(recordId: Long, notes: String) {
        viewModelScope.launch { sim.callRecordDao.updateNotes(recordId, notes.trim().ifEmpty { null }) }
    }

    fun setFollowUp(recordId: Long, followUpAt: Long?, done: Boolean = false) {
        viewModelScope.launch { sim.callRecordDao.updateFollowUp(recordId, followUpAt, done) }
    }

    fun markFollowUpDone(recordId: Long) {
        viewModelScope.launch {
            val existing = sim.callRecordDao.getById(recordId) ?: return@launch
            sim.callRecordDao.updateFollowUp(recordId, existing.followUpAt, true)
        }
    }

    fun summarizeImportedTranscript(recordId: Long, transcript: String) {
        viewModelScope.launch {
            val cleaned = transcript.trim()
            if (cleaned.isEmpty()) {
                sim.callRecordDao.updateTranscriptAndSummary(recordId, null, null)
                return@launch
            }
            val result = container.localAiEngine.analyzeText(cleaned, AiLanguage.AUTO)
            val formattedSummary = formatIntelligenceOutput(result)
            sim.callRecordDao.updateTranscriptAndSummary(recordId, cleaned, formattedSummary)
        }
    }

    // Module B actions
    fun analyzeNotesWithLocalAi(text: String, language: AiLanguage) {
        viewModelScope.launch(Dispatchers.Default) {
            _aiAnalysisResult.value = container.localAiEngine.analyzeText(text, language)
        }
    }

    fun searchLocalNotes(query: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val trimmed = query.trim()
            _noteSearchResults.value = if (trimmed.isEmpty()) {
                emptyList()
            } else {
                sim.callRecordDao.searchNotesAndSummaries(trimmed)
            }
        }
    }

    fun updateLocalAiModelPath(path: String) {
        viewModelScope.launch {
            container.cachedModelPath = path.trim()
            sim.preferencesRepository.setLocalAiModelPath(path.trim())
            _modelStatus.value = container.localAiEngine.inspectModelFile(path.trim())
        }
    }

    fun runLiveBenchmark() {
        viewModelScope.launch(Dispatchers.Default) {
            val path = container.cachedModelPath
            _modelStatus.value = container.localAiEngine.inspectModelFile(path)
            _benchmarkResult.value = ModelCatalogAndBenchmarks.runLiveDeviceBenchmark(
                engine = container.localAiEngine,
                modelPath = path
            )
        }
    }

    // Module C actions (VoIP only)
    fun updateSipProfile(profile: SipProfile) {
        container.voipReceptionistManager.updateSipProfile(profile)
    }

    fun startVoipCall(remoteParty: String, direction: CallDirection) {
        container.voipReceptionistManager.startVoipCall(remoteParty, direction)
    }

    fun submitVoipCallerUtterance(text: String) {
        container.voipReceptionistManager.submitCallerUtterance(text)
    }

    fun triggerVoipBargeIn() {
        container.voipReceptionistManager.simulateBargeIn()
    }

    fun takeOverVoipCall() {
        container.voipReceptionistManager.takeOverCall()
    }

    fun endVoipCallAndSave() {
        container.voipReceptionistManager.endVoipCall()
        val snap = container.voipReceptionistManager.session.value
        val transcriptText = snap.transcript.joinToString("\n") { "${it.speaker}: ${it.text}" }
        val summaryText = formatIntelligenceOutput(snap.summaryOutput)
        val norm = PhoneNumberNormalizer.normalize(snap.remoteParty)
        viewModelScope.launch {
            sim.callRecordDao.insert(
                CallRecordEntity(
                    rawNumber = snap.remoteParty.ifBlank { "VoIP Caller" },
                    normalizedNumber = norm.normalized,
                    last10Digits = norm.last10Digits,
                    callerName = snap.remoteParty,
                    timestamp = System.currentTimeMillis(),
                    status = if (snap.direction == CallDirection.OUTGOING) {
                        CallStatus.OUTGOING_PLACED
                    } else {
                        CallStatus.ANSWERED
                    },
                    callSource = CallSource.VOIP,
                    direction = snap.direction,
                    category = snap.detectedIntent ?: CallerCategory.UNKNOWN,
                    confidencePercent = 85,
                    isSavedContact = false,
                    screeningReason = "VoIP AI Receptionist Lab session",
                    importedTranscript = transcriptText.ifBlank { null },
                    localSummary = summaryText
                )
            )
        }
    }

    // Rules & Settings
    fun addOrUpdateRule(
        rawNumber: String,
        label: String?,
        ruleType: RuleType,
        category: CallerCategory
    ) {
        viewModelScope.launch {
            val norm = PhoneNumberNormalizer.normalize(rawNumber)
            if (norm.normalized.isEmpty()) return@launch
            sim.callerRuleDao.upsert(
                CallerRuleEntity(
                    normalizedNumber = norm.normalized,
                    last10Digits = norm.last10Digits,
                    displayLabel = label?.trim()?.ifEmpty { null },
                    ruleType = ruleType,
                    category = category,
                    createdAt = System.currentTimeMillis()
                )
            )
        }
    }

    fun deleteRule(normalizedNumber: String) {
        viewModelScope.launch { sim.callerRuleDao.deleteByNumber(normalizedNumber) }
    }

    fun setExplicitSilenceRules(enabled: Boolean) {
        viewModelScope.launch { sim.preferencesRepository.setExplicitSilenceRules(enabled) }
    }

    fun setExplicitBlockRules(enabled: Boolean) {
        viewModelScope.launch { sim.preferencesRepository.setExplicitBlockRules(enabled) }
    }

    fun setFloatingOverlayEnabled(enabled: Boolean) {
        viewModelScope.launch { sim.preferencesRepository.setFloatingOverlayEnabled(enabled) }
    }

    fun togglePromoFlagCategory(category: CallerCategory, enabled: Boolean) {
        viewModelScope.launch { sim.preferencesRepository.togglePromoFlagCategory(category, enabled) }
    }

    fun updateNotificationPref(
        personal: Boolean? = null,
        professional: Boolean? = null,
        banking: Boolean? = null,
        insurance: Boolean? = null,
        unknownWarning: Boolean? = null
    ) {
        viewModelScope.launch {
            sim.preferencesRepository.setNotificationPreferences(
                personal = personal,
                professional = professional,
                banking = banking,
                insurance = insurance,
                unknownWarning = unknownWarning
            )
        }
    }

    fun updateDailySummarySchedule(enabled: Boolean, hour: Int, minute: Int) {
        viewModelScope.launch {
            sim.preferencesRepository.setDailySummarySchedule(enabled, hour, minute)
            DailySummaryScheduler.schedule(appContext, enabled, hour, minute)
        }
    }

    fun setRetentionDays(days: Int) {
        viewModelScope.launch { sim.preferencesRepository.setRetentionDays(days) }
    }

    fun clearAllCallHistory() {
        viewModelScope.launch { sim.callRecordDao.deleteAll() }
    }

    fun testLocalScreening(
        rawNumber: String,
        callerDisplayName: String?,
        direction: CallDirection = CallDirection.INCOMING
    ) {
        viewModelScope.launch {
            val prefs = sim.preferencesRepository.getSnapshot()
            _simulatedScreeningResult.value = sim.classifier.classify(
                rawNumber = rawNumber,
                callerDisplayName = callerDisplayName,
                preferences = prefs,
                direction = direction,
                callSource = CallSource.SIM
            )
        }
    }

    private fun formatIntelligenceOutput(output: CallIntelligenceOutput?): String? {
        if (output == null) return null
        return buildString {
            if (output.summaryBullets.isNotEmpty()) {
                appendLine("Summary (${output.detectedLanguage.displayName}):")
                output.summaryBullets.forEach { appendLine("• $it") }
            }
            if (output.commitments.isNotEmpty()) {
                appendLine("Commitments:")
                output.commitments.forEach { appendLine("• $it") }
            }
            if (output.datesAndDeadlines.isNotEmpty()) {
                appendLine("Dates / Deadlines: ${output.datesAndDeadlines.joinToString(", ")}")
            }
            if (output.actionItems.isNotEmpty()) {
                appendLine("Action Items:")
                output.actionItems.forEach { appendLine("• $it") }
            }
            output.detectedCategoryHint?.let {
                append("Intent: ${it.displayName}")
            }
        }.trim().ifEmpty { null }
    }
}

class CallWiseViewModelFactory(
    private val appContext: Context,
    private val container: AppContainer
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return CallWiseViewModel(appContext.applicationContext, container) as T
    }
}

package com.callwise.ai.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.callwise.ai.ui.screens.CallHistoryScreen
import com.callwise.ai.ui.screens.CallerDetailsScreen
import com.callwise.ai.ui.screens.DailySummaryScreen
import com.callwise.ai.ui.screens.DashboardScreen
import com.callwise.ai.ui.screens.IncomingCallProtectionScreen
import com.callwise.ai.ui.screens.OfflineAiIntelligenceScreen
import com.callwise.ai.ui.screens.PromotionalCallManagerScreen
import com.callwise.ai.ui.screens.ProtectedContactsScreen
import com.callwise.ai.ui.screens.SettingsScreen
import com.callwise.ai.ui.screens.VoipReceptionistLabScreen

object Routes {
    const val DASHBOARD = "dashboard"
    const val OFFLINE_AI = "offline_ai"
    const val VOIP_LAB = "voip_lab"
    const val HISTORY = "history"
    const val SETTINGS = "settings"

    const val PROTECTION = "protection"
    const val CONTACTS = "contacts"
    const val PROMO_MANAGER = "promo_manager"
    const val DAILY_SUMMARY = "daily_summary"
    const val CALLER_DETAILS = "caller_details/{recordId}"

    fun callerDetails(recordId: Long) = "caller_details/$recordId"
}

private data class BottomNavItem(
    val route: String,
    val label: String,
    val icon: ImageVector
)

@Composable
fun CallWiseNavHost(
    viewModel: CallWiseViewModel,
    initialRecordId: Long? = null,
    openDailySummaryInitially: Boolean = false,
    onRequestScreeningRole: () -> Unit,
    onRequestContactsPermission: () -> Unit,
    onRequestPhoneStatePermission: () -> Unit,
    onRequestVoipAudioPermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit
) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val startDestination = when {
        initialRecordId != null && initialRecordId > 0L -> Routes.callerDetails(initialRecordId)
        openDailySummaryInitially -> Routes.DAILY_SUMMARY
        else -> Routes.DASHBOARD
    }

    val navItems = listOf(
        BottomNavItem(Routes.DASHBOARD, "SIM", Icons.Default.PhoneInTalk),
        BottomNavItem(Routes.OFFLINE_AI, "Offline AI", Icons.Default.AutoAwesome),
        BottomNavItem(Routes.VOIP_LAB, "VoIP Lab", Icons.Default.RecordVoiceOver),
        BottomNavItem(Routes.HISTORY, "History", Icons.Default.History),
        BottomNavItem(Routes.SETTINGS, "Settings", Icons.Default.Settings)
    )

    val showBottomBar = navItems.any { it.route == currentRoute }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    navItems.forEach { item ->
                        NavigationBarItem(
                            selected = currentRoute == item.route,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(Routes.DASHBOARD) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    viewModel = viewModel,
                    onRequestScreeningRole = onRequestScreeningRole,
                    onRequestContactsPermission = onRequestContactsPermission,
                    onRequestPhoneStatePermission = onRequestPhoneStatePermission,
                    onRequestOverlayPermission = onRequestOverlayPermission,
                    onNavigateToProtection = { navController.navigate(Routes.PROTECTION) },
                    onNavigateToContacts = { navController.navigate(Routes.CONTACTS) },
                    onNavigateToPromoManager = { navController.navigate(Routes.PROMO_MANAGER) },
                    onNavigateToDailySummary = { navController.navigate(Routes.DAILY_SUMMARY) },
                    onOpenCallerDetails = { id -> navController.navigate(Routes.callerDetails(id)) }
                )
            }
            composable(Routes.OFFLINE_AI) {
                OfflineAiIntelligenceScreen(
                    viewModel = viewModel,
                    onOpenCallerDetails = { id -> navController.navigate(Routes.callerDetails(id)) }
                )
            }
            composable(Routes.VOIP_LAB) {
                VoipReceptionistLabScreen(
                    viewModel = viewModel,
                    onRequestVoipAudioPermission = onRequestVoipAudioPermission
                )
            }
            composable(Routes.PROTECTION) {
                IncomingCallProtectionScreen(
                    viewModel = viewModel,
                    onOpenCallerDetails = { id -> navController.navigate(Routes.callerDetails(id)) }
                )
            }
            composable(Routes.CONTACTS) {
                ProtectedContactsScreen(
                    viewModel = viewModel,
                    onRequestContactsPermission = onRequestContactsPermission
                )
            }
            composable(Routes.HISTORY) {
                CallHistoryScreen(
                    viewModel = viewModel,
                    onOpenCallerDetails = { id -> navController.navigate(Routes.callerDetails(id)) }
                )
            }
            composable(Routes.PROMO_MANAGER) {
                PromotionalCallManagerScreen(viewModel = viewModel)
            }
            composable(Routes.DAILY_SUMMARY) {
                DailySummaryScreen(
                    viewModel = viewModel,
                    onOpenCallerDetails = { id -> navController.navigate(Routes.callerDetails(id)) }
                )
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(
                    viewModel = viewModel,
                    onRequestScreeningRole = onRequestScreeningRole,
                    onRequestContactsPermission = onRequestContactsPermission,
                    onRequestPhoneStatePermission = onRequestPhoneStatePermission,
                    onRequestNotificationPermission = onRequestNotificationPermission,
                    onRequestOverlayPermission = onRequestOverlayPermission
                )
            }
            composable(
                route = Routes.CALLER_DETAILS,
                arguments = listOf(navArgument("recordId") { type = NavType.LongType })
            ) { entry ->
                val recordId = entry.arguments?.getLong("recordId") ?: 0L
                CallerDetailsScreen(
                    recordId = recordId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

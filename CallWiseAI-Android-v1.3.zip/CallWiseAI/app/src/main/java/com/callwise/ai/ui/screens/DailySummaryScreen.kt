package com.callwise.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.SectionHeader
import com.callwise.ai.ui.components.ShareHelper
import com.callwise.ai.ui.components.StatCard
import com.callwise.ai.ui.theme.AlertRed
import com.callwise.ai.ui.theme.DeepTeal
import com.callwise.ai.ui.theme.SafeGreen
import com.callwise.ai.ui.theme.WarmAmber

@Composable
fun DailySummaryScreen(
    viewModel: CallWiseViewModel,
    onOpenCallerDetails: (Long) -> Unit
) {
    val context = LocalContext.current
    val metrics by viewModel.dailyMetrics.collectAsState()
    val followUps by viewModel.pendingFollowUps.collectAsState()
    val calls by viewModel.callRecords.collectAsState()

    val shareText = buildString {
        appendLine("CallWise AI Daily Summary")
        appendLine("• Incoming calls today: ${metrics.totalToday}")
        appendLine("• Important calls: ${metrics.importantToday}")
        appendLine("• Blocked promotional/spam: ${metrics.blockedToday}")
        appendLine("• Missed calls: ${metrics.missedToday}")
        appendLine("• Pending follow-ups: ${followUps.size}")
        if (followUps.isNotEmpty()) {
            appendLine("\nFollow-ups:")
            followUps.take(5).forEach {
                appendLine("- ${it.callerName ?: it.rawNumber}: ${it.userNotes ?: "Follow up"}")
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Daily Summary",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = {
                        ShareHelper.shareText(context, "CallWise AI Daily Summary", shareText)
                    }
                ) {
                    Icon(Icons.Default.Share, contentDescription = null)
                    Text(" Share", modifier = Modifier.padding(start = 4.dp))
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Incoming", metrics.totalToday.toString(), DeepTeal, Modifier.weight(1f))
                StatCard("Important", metrics.importantToday.toString(), SafeGreen, Modifier.weight(1f))
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Blocked", metrics.blockedToday.toString(), AlertRed, Modifier.weight(1f))
                StatCard("Missed", metrics.missedToday.toString(), WarmAmber, Modifier.weight(1f))
            }
        }

        item {
            SectionHeader(title = "Pending Follow-up Tasks (${followUps.size})")
        }

        if (followUps.isEmpty()) {
            item {
                Text(
                    text = "No pending follow-ups.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(followUps, key = { "sum_fu_${it.id}" }) { record ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = record.callerName ?: record.rawNumber,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = record.userNotes ?: "Follow-up scheduled",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { onOpenCallerDetails(record.id) }) {
                                Text("Open")
                            }
                            Button(onClick = { viewModel.markFollowUpDone(record.id) }) {
                                Text("Done")
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Important Events Today")
        }

        val importantRecent = calls.filter { it.category.isImportant }.take(5)
        if (importantRecent.isEmpty()) {
            item {
                Text(
                    text = "No important calls recorded yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(importantRecent, key = { "imp_${it.id}" }) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(
                            text = "${item.callerName ?: item.rawNumber} (${item.category.displayName})",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = item.screeningReason,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

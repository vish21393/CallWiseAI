package com.callwise.ai

import android.app.Application
import android.content.Context
import com.callwise.ai.ai.LocalAiEngine
import com.callwise.ai.ai.MultilingualLocalAiEngine
import com.callwise.ai.notifications.DailySummaryScheduler
import com.callwise.ai.sim.SimAssistantContainer
import com.callwise.ai.sim.SimAssistantHost
import com.callwise.ai.voip.VoipReceptionistManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    // Module A: SIM Call Assistant (100% offline, no INTERNET or RECORD_AUDIO)
    val simContainer: SimAssistantContainer by lazy { SimAssistantContainer(appContext) }

    // Module B: Offline AI Personal Intelligence (100% offline)
    @Volatile
    var cachedModelPath: String = ""
    val localAiEngine: LocalAiEngine by lazy {
        MultilingualLocalAiEngine(modelPathProvider = { cachedModelPath })
    }

    // Module C: AI Receptionist Lab (VoIP only)
    val voipReceptionistManager: VoipReceptionistManager by lazy {
        VoipReceptionistManager(appContext, localAiEngine)
    }
}

class CallWiseApplication : Application(), SimAssistantHost {
    lateinit var container: AppContainer
        private set

    override val simContainer: SimAssistantContainer
        get() = container.simContainer

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        simContainer.notificationManager.createChannels()
        simContainer.contactsChangeObserver.register()
        simContainer.callStateMonitor.register()

        appScope.launch {
            val prefs = simContainer.preferencesRepository.getSnapshot()
            container.cachedModelPath = prefs.localAiModelPath
            DailySummaryScheduler.schedule(
                context = this@CallWiseApplication,
                enabled = prefs.dailySummaryEnabled,
                hour = prefs.dailySummaryHour,
                minute = prefs.dailySummaryMinute
            )
            if (simContainer.contactsSyncManager.hasContactsPermission()) {
                simContainer.contactsSyncManager.syncContacts()
            }
        }
    }
}

package com.callwise.ai.ui.screens

import android.app.TimePickerDialog
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.DateFormatters
import com.callwise.ai.ui.components.SectionHeader
import com.callwise.ai.ui.theme.SafeGreen

@Composable
fun SettingsScreen(
    viewModel: CallWiseViewModel,
    onRequestScreeningRole: () -> Unit,
    onRequestContactsPermission: () -> Unit,
    onRequestPhoneStatePermission: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit
) {
    val context = LocalContext.current
    val prefs by viewModel.preferences.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Settings & Privacy",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "100% On-Device Privacy & Module Isolation",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SafeGreen
                    )
                    Text(
                        text = "Module A (SIM Assistant) and Module B (Offline AI) have zero network permissions. Google Phone stays your default dialer. Only Module C (VoIP Lab) requests microphone/network for SIP/VoIP tests.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item {
            SectionHeader(title = "Permissions & Android Role")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Call Screening Role: ${if (viewModel.isCallScreeningRoleHeld()) "Active" else "Not Active"}")
                    if (!viewModel.isCallScreeningRoleHeld()) {
                        OutlinedButton(onClick = onRequestScreeningRole) { Text("Set Call Screening App") }
                    }

                    Text("Display Over Other Apps (Google Phone Overlay): ${if (viewModel.hasOverlayPermission()) "Granted" else "Not Granted"}")
                    if (!viewModel.hasOverlayPermission()) {
                        OutlinedButton(onClick = onRequestOverlayPermission) { Text("Allow Floating Overlay") }
                    }

                    Text("Phone State (Call-End & Outgoing Detection): ${if (viewModel.hasPhoneStatePermission()) "Granted" else "Not Granted"}")
                    if (!viewModel.hasPhoneStatePermission()) {
                        OutlinedButton(onClick = onRequestPhoneStatePermission) { Text("Allow Call State Detection") }
                    }

                    Text("Contacts Permission: ${if (viewModel.hasContactsPermission()) "Granted" else "Missing"}")
                    if (!viewModel.hasContactsPermission()) {
                        OutlinedButton(onClick = onRequestContactsPermission) { Text("Grant Contacts") }
                    }

                    Text("Notifications Permission: ${if (viewModel.hasNotificationPermission()) "Granted" else "Missing"}")
                    if (!viewModel.hasNotificationPermission()) {
                        OutlinedButton(onClick = onRequestNotificationPermission) { Text("Grant Notifications") }
                    }
                }
            }
        }

        item {
            SectionHeader(title = "SIM Call Screening Rules (Advisory by Default)")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SettingToggle(
                        label = "Float CallWise card over Google Phone",
                        checked = prefs.floatingOverlayEnabled
                    ) { viewModel.setFloatingOverlayEnabled(it) }

                    SettingToggle(
                        label = "Enforce explicit Silence rules (incoming only)",
                        checked = prefs.enableExplicitSilenceRules
                    ) { viewModel.setExplicitSilenceRules(it) }

                    SettingToggle(
                        label = "Enforce explicit Block rules (incoming only)",
                        checked = prefs.enableExplicitBlockRules
                    ) { viewModel.setExplicitBlockRules(it) }

                    Text(
                        text = "Saved contacts always override Silence and Block rules.",
                        style = MaterialTheme.typography.labelSmall,
                        color = SafeGreen
                    )
                }
            }
        }

        item {
            SectionHeader(title = "Offline Notifications & Daily Summary")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SettingToggle("Personal call alerts", prefs.notifyPersonal) {
                        viewModel.updateNotificationPref(personal = it)
                    }
                    SettingToggle("Professional / recruiter alerts", prefs.notifyProfessional) {
                        viewModel.updateNotificationPref(professional = it)
                    }
                    SettingToggle("Banking & financial alerts", prefs.notifyBanking) {
                        viewModel.updateNotificationPref(banking = it)
                    }
                    SettingToggle("Insurance servicing alerts", prefs.notifyInsurance) {
                        viewModel.updateNotificationPref(insurance = it)
                    }
                    SettingToggle("Unknown caller warnings", prefs.notifyUnknownWarning) {
                        viewModel.updateNotificationPref(unknownWarning = it)
                    }
                    SettingToggle("Daily Summary notification", prefs.dailySummaryEnabled) {
                        viewModel.updateDailySummarySchedule(it, prefs.dailySummaryHour, prefs.dailySummaryMinute)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Summary Time: ${DateFormatters.formatTime(prefs.dailySummaryHour, prefs.dailySummaryMinute)}")
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(
                                    context,
                                    { _, hour, minute ->
                                        viewModel.updateDailySummarySchedule(prefs.dailySummaryEnabled, hour, minute)
                                    },
                                    prefs.dailySummaryHour,
                                    prefs.dailySummaryMinute,
                                    false
                                ).show()
                            }
                        ) { Text("Change Time") }
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Data Retention & Deletion")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Keep local call history for:", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(30 to "30d", 90 to "90d", 365 to "1y", 0 to "Forever").forEach { (days, label) ->
                            FilterChip(
                                selected = prefs.retentionDays == days,
                                onClick = { viewModel.setRetentionDays(days) },
                                label = { Text(label) }
                            )
                        }
                    }
                    Button(
                        onClick = { viewModel.clearAllCallHistory() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Delete All Call History")
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingToggle(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

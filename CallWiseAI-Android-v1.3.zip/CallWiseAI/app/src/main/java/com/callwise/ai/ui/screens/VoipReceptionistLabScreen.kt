package com.callwise.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.SectionHeader
import com.callwise.ai.voip.VoipCallState

@Composable
fun VoipReceptionistLabScreen(
    viewModel: CallWiseViewModel,
    onRequestVoipAudioPermission: () -> Unit
) {
    val session by viewModel.voipSession.collectAsState()
    val sipProfile by viewModel.sipProfile.collectAsState()
    val hasMicPerm = viewModel.hasVoipAudioPermission()

    var remoteParty by remember { mutableStateOf("sip:recruiter@example.com") }
    var direction by remember { mutableStateOf(CallDirection.INCOMING) }
    var callerUtterance by remember { mutableStateOf("") }
    var sipHostInput by remember(sipProfile.serverHost) { mutableStateOf(sipProfile.serverHost) }

    val isCallActive = session.callState == VoipCallState.AI_CONVERSING ||
        session.callState == VoipCallState.USER_TAKEOVER

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "AI Receptionist Lab (VoIP Only)",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Module C • Experimental VoIP/SIP pipeline • Does NOT intercept normal SIM calls",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        if (!hasMicPerm) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "Microphone Permission (VoIP Barge-In Only)",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            "Required only inside this VoIP Lab to detect caller speech for live TTS barge-in. Never used on SIM calls.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Button(onClick = onRequestVoipAudioPermission) {
                            Text("Grant VoIP Microphone Permission")
                        }
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("SIP / Local Loopback Environment", fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Local Loopback Test Mode (Offline)", modifier = Modifier.weight(1f))
                        Switch(
                            checked = sipProfile.useLocalLoopback,
                            onCheckedChange = {
                                viewModel.updateSipProfile(sipProfile.copy(useLocalLoopback = it))
                            }
                        )
                    }
                    if (!sipProfile.useLocalLoopback) {
                        OutlinedTextField(
                            value = sipHostInput,
                            onValueChange = { sipHostInput = it },
                            label = { Text("SIP Server Host (e.g. sip.example.com)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedButton(
                            onClick = {
                                viewModel.updateSipProfile(sipProfile.copy(serverHost = sipHostInput))
                            }
                        ) {
                            Text("Save SIP Endpoint")
                        }
                    }
                    Text(
                        text = session.statusNote,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "[VoIP] State: ${session.callState.displayName} • Barge-ins: ${session.bargeInCount}",
                        fontWeight = FontWeight.SemiBold
                    )
                    if (!isCallActive) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CallDirection.entries.forEach { dir ->
                                FilterChip(
                                    selected = direction == dir,
                                    onClick = { direction = dir },
                                    label = { Text("VoIP ${dir.displayName}") }
                                )
                            }
                        }
                        OutlinedTextField(
                            value = remoteParty,
                            onValueChange = { remoteParty = it },
                            label = { Text("Remote SIP URI / Name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(onClick = { viewModel.startVoipCall(remoteParty, direction) }) {
                            Text("Start VoIP Call")
                        }
                    } else {
                        Text(
                            text = "TTS Speaking: ${if (session.isTtsSpeaking) "Yes" else "No"} • " +
                                "Detected Intent: ${session.detectedIntent?.displayName ?: "Listening..."}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedTextField(
                            value = callerUtterance,
                            onValueChange = { callerUtterance = it },
                            label = { Text("Caller speech / test utterance") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    viewModel.submitVoipCallerUtterance(callerUtterance)
                                    callerUtterance = ""
                                },
                                enabled = callerUtterance.isNotBlank()
                            ) { Text("Send Turn") }

                            OutlinedButton(onClick = { viewModel.triggerVoipBargeIn() }) {
                                Text("Barge-In")
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (session.callState == VoipCallState.AI_CONVERSING) {
                                OutlinedButton(onClick = { viewModel.takeOverVoipCall() }) {
                                    Text("User Takeover")
                                }
                            }
                            Button(
                                onClick = { viewModel.endVoipCallAndSave() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text("End & Summarise")
                            }
                        }
                    }
                }
            }
        }

        if (session.transcript.isNotEmpty()) {
            item { SectionHeader(title = "Live VoIP Transcript") }
            items(session.transcript, key = { "vt_${it.id}" }) { turn ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(10.dp)) {
                        Text(turn.speaker, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Text(turn.text, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        session.summaryOutput?.let { out ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("Post-Call VoIP Summary", fontWeight = FontWeight.Bold)
                        out.summaryBullets.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        if (out.actionItems.isNotEmpty()) {
                            Text("Action Items:", fontWeight = FontWeight.SemiBold)
                            out.actionItems.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
        }
    }
}

package com.callwise.ai.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.ai.AiLanguage
import com.callwise.ai.ai.ModelCatalogAndBenchmarks
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.SectionHeader
import com.callwise.ai.ui.theme.SafeGreen

@Composable
fun OfflineAiIntelligenceScreen(
    viewModel: CallWiseViewModel,
    onOpenCallerDetails: (Long) -> Unit
) {
    val prefs by viewModel.preferences.collectAsState()
    val analysis by viewModel.aiAnalysisResult.collectAsState()
    val noteResults by viewModel.noteSearchResults.collectAsState()
    val modelStatus by viewModel.modelStatus.collectAsState()
    val benchmark by viewModel.benchmarkResult.collectAsState()

    var transcriptInput by remember { mutableStateOf("") }
    var selectedLang by remember { mutableStateOf(AiLanguage.AUTO) }
    var searchQuery by remember { mutableStateOf("") }
    var modelPathInput by remember(prefs.localAiModelPath) {
        mutableStateOf(prefs.localAiModelPath)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Offline AI Personal Intelligence",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Module B • 100% offline • Zero INTERNET permission • Never invents transcripts",
                style = MaterialTheme.typography.labelSmall,
                color = SafeGreen
            )
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Summarise Transcript / Notes", fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AiLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = selectedLang == lang,
                                onClick = { selectedLang = lang },
                                label = { Text(lang.displayName) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = transcriptInput,
                        onValueChange = { transcriptInput = it },
                        label = { Text("Paste call transcript or notes (EN / HI / TE)") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = { viewModel.analyzeNotesWithLocalAi(transcriptInput, selectedLang) },
                        enabled = transcriptInput.isNotBlank()
                    ) {
                        Text("Extract Summary & Commitments")
                    }

                    analysis?.let { out ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "${out.engineUsed} • ${out.detectedLanguage.displayName} • ${out.latencyMs}ms",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (out.summaryBullets.isNotEmpty()) {
                                    Text("Summary:", fontWeight = FontWeight.SemiBold)
                                    out.summaryBullets.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                                }
                                if (out.commitments.isNotEmpty()) {
                                    Text("Commitments:", fontWeight = FontWeight.SemiBold)
                                    out.commitments.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                                }
                                if (out.datesAndDeadlines.isNotEmpty()) {
                                    Text(
                                        "Dates / Deadlines: ${out.datesAndDeadlines.joinToString(", ")}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                if (out.actionItems.isNotEmpty()) {
                                    Text("Action Items:", fontWeight = FontWeight.SemiBold)
                                    out.actionItems.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                                }
                                out.detectedCategoryHint?.let {
                                    Text(
                                        "Caller Intent: ${it.displayName}",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Search Previous Notes & Summaries")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        viewModel.searchLocalNotes(it)
                    },
                    label = { Text("Search keywords, dates, or caller name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        items(noteResults, key = { "note_${it.id}" }) { rec ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenCallerDetails(rec.id) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(rec.callerName ?: rec.rawNumber, fontWeight = FontWeight.SemiBold)
                    rec.userNotes?.let { Text("Note: $it", style = MaterialTheme.typography.bodySmall) }
                    rec.localSummary?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
        }

        item {
            SectionHeader(title = "Optional Local Model & Vivo X100 Pro Benchmark")
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = modelPathInput,
                        onValueChange = { modelPathInput = it },
                        label = { Text("Optional local .task / .gguf model path") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { viewModel.updateLocalAiModelPath(modelPathInput) }) {
                            Text("Verify Model Path")
                        }
                        Button(onClick = { viewModel.runLiveBenchmark() }) {
                            Text("Run Live Benchmark")
                        }
                    }

                    modelStatus?.let { status ->
                        Text(status.statusMessage, style = MaterialTheme.typography.bodySmall)
                    }

                    benchmark?.let { bm ->
                        Text(
                            text = "Measured: Load/Inspect ${bm.modelInspectTimeMs}ms • Inference ${bm.inferenceLatencyMs}ms • " +
                                "JVM Heap ${bm.jvmHeapUsedMb}MB • Native Heap ${bm.nativeHeapMb}MB",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Recommended Models (Vivo X100 Pro • 16 GB RAM)")
        }

        items(ModelCatalogAndBenchmarks.vivoX100ProCatalog, key = { it.name }) { model ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text("${model.name} (${model.quantization})", fontWeight = FontWeight.SemiBold)
                    Text(
                        "${model.role} • Disk: ${model.diskSizeGb} • RAM: ${model.expectedRamGb}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        "Languages: ${model.languageSupport}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(model.notes, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

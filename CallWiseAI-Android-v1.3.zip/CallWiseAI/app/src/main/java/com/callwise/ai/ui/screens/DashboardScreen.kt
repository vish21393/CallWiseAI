package com.callwise.ai.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.CategoryBadge
import com.callwise.ai.ui.components.DateFormatters
import com.callwise.ai.ui.components.SectionHeader
import com.callwise.ai.ui.components.StatCard
import com.callwise.ai.ui.theme.AlertRed
import com.callwise.ai.ui.theme.DeepTeal
import com.callwise.ai.ui.theme.SafeGreen
import com.callwise.ai.ui.theme.WarmAmber

@Composable
fun DashboardScreen(
    viewModel: CallWiseViewModel,
    onRequestScreeningRole: () -> Unit,
    onRequestContactsPermission: () -> Unit,
    onRequestPhoneStatePermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onNavigateToProtection: () -> Unit,
    onNavigateToContacts: () -> Unit,
    onNavigateToPromoManager: () -> Unit,
    onNavigateToDailySummary: () -> Unit,
    onOpenCallerDetails: (Long) -> Unit
) {
    val metrics by viewModel.dailyMetrics.collectAsState()
    val followUps by viewModel.pendingFollowUps.collectAsState()
    val recentCalls by viewModel.callRecords.collectAsState()
    val contactCount by viewModel.distinctContactCount.collectAsState()
    val prefs by viewModel.preferences.collectAsState()

    val hasScreeningRole = viewModel.isCallScreeningRoleHeld()
    val hasContactsPerm = viewModel.hasContactsPermission()
    val hasPhoneStatePerm = viewModel.hasPhoneStatePermission()
    val hasOverlayPerm = viewModel.hasOverlayPermission()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text(
                    text = "CallWise AI • SIM Assistant",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Know who's calling. Protect your time. Remember what matters.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (!hasScreeningRole || !hasContactsPerm || !hasPhoneStatePerm || !hasOverlayPerm) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("SIM Assistant Setup", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        if (!hasScreeningRole) {
                            Text("Set CallWise AI as your Call Screening app (Google Phone stays default dialer).", style = MaterialTheme.typography.bodySmall)
                            Button(onClick = onRequestScreeningRole) { Text("Enable Call Screening Role") }
                        }
                        if (!hasContactsPerm) {
                            Text("Grant Contacts permission so saved & Google-synced contacts are protected.", style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = onRequestContactsPermission) { Text("Allow Contacts Access") }
                        }
                        if (!hasPhoneStatePerm) {
                            Text("Grant Phone State permission for automatic call-end overlay dismissal.", style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = onRequestPhoneStatePermission) { Text("Allow Call State Detection") }
                        }
                        if (!hasOverlayPerm) {
                            Text("Allow Display over other apps to float CallWise AI over Google Phone.", style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = onRequestOverlayPermission) { Text("Allow Floating Overlay") }
                        }
                    }
                }
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Calls Today", metrics.totalToday.toString(), DeepTeal, Modifier.weight(1f))
                StatCard("Important", metrics.importantToday.toString(), SafeGreen, Modifier.weight(1f))
            }
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Flagged", metrics.flaggedToday.toString(), AlertRed, Modifier.weight(1f))
                StatCard("Follow-ups", followUps.size.toString(), WarmAmber, Modifier.weight(1f))
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Module A Status", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "Protected Contacts: $contactCount • Last sync: ${DateFormatters.formatDateTime(prefs.lastContactSyncTime)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "100% offline • No INTERNET permission • Advisory by default",
                        style = MaterialTheme.typography.labelSmall,
                        color = SafeGreen
                    )
                }
            }
        }

        item {
            SectionHeader(title = "SIM Tools")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onNavigateToProtection, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Security, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Screen")
                }
                OutlinedButton(onClick = onNavigateToContacts, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Contacts, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Contacts")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onNavigateToPromoManager, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Block, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Rules")
                }
                OutlinedButton(onClick = onNavigateToDailySummary, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Summarize, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Summary")
                }
            }
        }

        if (followUps.isNotEmpty()) {
            item { SectionHeader(title = "Pending Follow-ups") }
            items(followUps.take(3), key = { "followup_${it.id}" }) { record ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenCallerDetails(record.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "[${record.callSource.displayName}] ${record.callerName ?: record.rawNumber}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                record.userNotes ?: "Follow-up reminder",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = WarmAmber)
                    }
                }
            }
        }

        item { SectionHeader(title = "Recent Calls (SIM & VoIP)") }

        if (recentCalls.isEmpty()) {
            item {
                Text(
                    "No calls logged yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(recentCalls.take(5), key = { "recent_${it.id}" }) { record ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenCallerDetails(record.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "[${record.callSource.displayName}] ${record.callerName ?: record.rawNumber}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            CategoryBadge(category = record.category)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${record.direction.displayName} • ${record.status.displayName} • ${record.confidencePercent}% • ${DateFormatters.formatDateTime(record.timestamp)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

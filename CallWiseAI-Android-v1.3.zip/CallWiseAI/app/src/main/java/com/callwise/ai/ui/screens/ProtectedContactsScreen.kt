package com.callwise.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.contacts.SyncState
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.DateFormatters
import com.callwise.ai.ui.theme.SafeGreen

@Composable
fun ProtectedContactsScreen(
    viewModel: CallWiseViewModel,
    onRequestContactsPermission: () -> Unit
) {
    val contacts by viewModel.contacts.collectAsState()
    val distinctCount by viewModel.distinctContactCount.collectAsState()
    val prefs by viewModel.preferences.collectAsState()
    val syncState by viewModel.syncState.collectAsState()
    val hasPerm = viewModel.hasContactsPermission()

    var searchQuery by remember { mutableStateOf("") }

    val filtered = remember(contacts, searchQuery) {
        if (searchQuery.isBlank()) {
            contacts
        } else {
            val q = searchQuery.trim().lowercase()
            contacts.filter {
                it.displayName.lowercase().contains(q) ||
                    it.rawNumber.lowercase().contains(q)
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                text = "Protected Contacts",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Synced from Android Contacts Provider (including Google Contacts). Saved contacts always override spam rules.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Permission: ${if (hasPerm) "Granted" else "Not Granted"}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (hasPerm) SafeGreen else MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = "Protected Contacts: $distinctCount (${contacts.size} numbers indexed)",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "Last Sync: ${DateFormatters.formatDateTime(prefs.lastContactSyncTime)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Status: ${
                            when (syncState) {
                                is SyncState.Syncing -> "Syncing..."
                                is SyncState.Success -> "Up to date"
                                is SyncState.PermissionMissing -> "Permission required"
                                is SyncState.Error -> (syncState as SyncState.Error).message
                                SyncState.Idle -> "Ready"
                            }
                        }",
                        style = MaterialTheme.typography.labelSmall
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (hasPerm) {
                            Button(onClick = { viewModel.syncContactsNow() }) {
                                Text("Sync Now")
                            }
                        } else {
                            OutlinedButton(onClick = onRequestContactsPermission) {
                                Text("Grant Contacts Permission")
                            }
                        }
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search protected contacts") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        items(filtered, key = { "contact_${it.id}" }) { contact ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = contact.displayName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = contact.rawNumber,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    contact.label?.let {
                        Text(
                            text = it,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

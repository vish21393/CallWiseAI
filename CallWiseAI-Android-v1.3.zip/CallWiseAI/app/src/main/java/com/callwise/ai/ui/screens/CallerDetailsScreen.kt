package com.callwise.ai.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.RuleType
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.CategoryBadge
import com.callwise.ai.ui.components.DateFormatters
import com.callwise.ai.ui.components.SectionHeader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallerDetailsScreen(
    recordId: Long,
    viewModel: CallWiseViewModel,
    onBack: () -> Unit
) {
    val record by viewModel.observeCallRecord(recordId).collectAsState(initial = null)
    val currentRecord = record

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Caller Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (currentRecord == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                Text("Call record not found.")
            }
            return@Scaffold
        }

        val previousInteractions by viewModel
            .observeHistoryForNumber(currentRecord.rawNumber)
            .collectAsState(initial = emptyList())

        var notesInput by remember(currentRecord.id, currentRecord.userNotes) {
            mutableStateOf(currentRecord.userNotes.orEmpty())
        }
        var transcriptInput by remember(currentRecord.id, currentRecord.importedTranscript) {
            mutableStateOf(currentRecord.importedTranscript.orEmpty())
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = currentRecord.callerName ?: currentRecord.rawNumber,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = currentRecord.rawNumber,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        CategoryBadge(category = currentRecord.category)
                        Text(
                            text = "Status: ${currentRecord.status.displayName} • ${DateFormatters.formatDateTime(currentRecord.timestamp)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = currentRecord.screeningReason,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (!currentRecord.isSavedContact) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        viewModel.addOrUpdateRule(
                                            currentRecord.rawNumber,
                                            currentRecord.callerName,
                                            RuleType.ALLOWLIST,
                                            currentRecord.category
                                        )
                                    }
                                ) { Text("Allowlist") }
                                OutlinedButton(
                                    onClick = {
                                        viewModel.addOrUpdateRule(
                                            currentRecord.rawNumber,
                                            currentRecord.callerName,
                                            RuleType.BLOCKLIST,
                                            CallerCategory.SUSPECTED_SPAM
                                        )
                                    }
                                ) { Text("Blocklist") }
                            }
                        }
                    }
                }
            }

            item {
                SectionHeader(title = "Call Status & Classification")
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CallStatus.entries.forEach { status ->
                        FilterChip(
                            selected = currentRecord.status == status,
                            onClick = {
                                viewModel.updateStatusAndDuration(
                                    currentRecord.id,
                                    status,
                                    currentRecord.durationSeconds
                                )
                            },
                            label = { Text(status.displayName) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CallerCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = currentRecord.category == cat,
                            onClick = { viewModel.updateCategory(currentRecord.id, cat) },
                            label = { Text(cat.displayName) }
                        )
                    }
                }
            }

            item {
                SectionHeader(title = "Notes & Follow-up Reminder")
                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("Manual notes (stored locally)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.updateNotes(currentRecord.id, notesInput) }) {
                        Text("Save Note")
                    }
                    if (currentRecord.followUpAt == null || currentRecord.followUpDone) {
                        OutlinedButton(
                            onClick = {
                                val tomorrow = System.currentTimeMillis() + 24L * 60 * 60 * 1000
                                viewModel.setFollowUp(currentRecord.id, tomorrow, done = false)
                            }
                        ) {
                            Text("Remind in 24h")
                        }
                    } else {
                        OutlinedButton(onClick = { viewModel.markFollowUpDone(currentRecord.id) }) {
                            Text("Mark Follow-up Done")
                        }
                    }
                }
            }

            item {
                SectionHeader(title = "Local Transcript Summariser")
                Text(
                    text = "Paste an imported transcript or call notes to extract key points and action items locally. Never invents summaries from metadata.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = transcriptInput,
                    onValueChange = { transcriptInput = it },
                    label = { Text("Imported transcript or detailed notes") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        viewModel.summarizeImportedTranscript(currentRecord.id, transcriptInput)
                    }
                ) {
                    Text("Summarise Locally")
                }

                currentRecord.localSummary?.let { summary ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = summary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            item {
                SectionHeader(title = "Previous Interactions (${previousInteractions.size})")
            }

            items(previousInteractions, key = { "prev_${it.id}" }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "${item.status.displayName} • ${DateFormatters.formatDateTime(item.timestamp)}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium
                        )
                        item.userNotes?.let {
                            Text(text = it, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

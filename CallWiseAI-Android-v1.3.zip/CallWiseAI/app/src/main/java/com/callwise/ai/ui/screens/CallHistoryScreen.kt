package com.callwise.ai.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.domain.model.CallSource
import com.callwise.ai.domain.model.CallStatus
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.CategoryBadge
import com.callwise.ai.ui.components.DateFormatters

private enum class HistoryFilter(val label: String) {
    ALL("All"),
    SIM_ONLY("SIM"),
    VOIP_ONLY("VoIP"),
    IMPORTANT("Important"),
    FOLLOW_UPS("Follow-ups"),
    FLAGGED("Blocked/Silenced")
}

@Composable
fun CallHistoryScreen(
    viewModel: CallWiseViewModel,
    onOpenCallerDetails: (Long) -> Unit
) {
    val records by viewModel.callRecords.collectAsState()
    var query by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(HistoryFilter.ALL) }

    val filtered = remember(records, query, selectedFilter) {
        records.filter { record ->
            val matchesFilter = when (selectedFilter) {
                HistoryFilter.ALL -> true
                HistoryFilter.SIM_ONLY -> record.callSource == CallSource.SIM
                HistoryFilter.VOIP_ONLY -> record.callSource == CallSource.VOIP
                HistoryFilter.IMPORTANT -> record.category.isImportant
                HistoryFilter.FOLLOW_UPS -> record.followUpAt != null && !record.followUpDone
                HistoryFilter.FLAGGED -> record.status == CallStatus.BLOCKED_BY_RULE ||
                    record.status == CallStatus.SILENCED_BY_RULE ||
                    record.status == CallStatus.REJECTED
            }
            val matchesQuery = if (query.isBlank()) {
                true
            } else {
                val q = query.trim().lowercase()
                (record.callerName?.lowercase()?.contains(q) == true) ||
                    record.rawNumber.lowercase().contains(q) ||
                    (record.userNotes?.lowercase()?.contains(q) == true)
            }
            matchesFilter && matchesQuery
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Call History", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search name, number, or notes") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HistoryFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.label) }
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            item {
                Text("No matching call records.", style = MaterialTheme.typography.bodySmall)
            }
        } else {
            items(filtered, key = { "hist_${it.id}" }) { record ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onOpenCallerDetails(record.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "[${record.callSource.displayName}] ${record.callerName ?: record.rawNumber}",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            CategoryBadge(category = record.category)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${record.direction.displayName} • ${record.status.displayName} • ${DateFormatters.formatDateTime(record.timestamp)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        record.userNotes?.let { notes ->
                            Spacer(Modifier.height(4.dp))
                            Text("Note: $notes", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

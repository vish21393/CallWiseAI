package com.callwise.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DeepTeal = Color(0xFF0F4C5C)
val DeepTealLight = Color(0xFF1F6E8C)
val WarmAmber = Color(0xFFE36414)
val SafeGreen = Color(0xFF1B7F5C)
val AlertRed = Color(0xFFB3261E)
val SlateBackground = Color(0xFFF6F8FA)
val SlateSurface = Color(0xFFFFFFFF)

private val LightColors = lightColorScheme(
    primary = DeepTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD0E8EE),
    onPrimaryContainer = Color(0xFF062933),
    secondary = WarmAmber,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE0CC),
    onSecondaryContainer = Color(0xFF4A1D00),
    background = SlateBackground,
    onBackground = Color(0xFF141B1F),
    surface = SlateSurface,
    onSurface = Color(0xFF141B1F),
    error = AlertRed,
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF6BC2D9),
    onPrimary = Color(0xFF003642),
    primaryContainer = DeepTeal,
    onPrimaryContainer = Color(0xFFD0E8EE),
    secondary = Color(0xFFFFB68B),
    onSecondary = Color(0xFF522300),
    background = Color(0xFF0F1417),
    onBackground = Color(0xFFE2E8EC),
    surface = Color(0xFF171E22),
    onSurface = Color(0xFFE2E8EC),
    error = Color(0xFFF2B8B5),
    onError = Color(0xFF601410)
)

@Composable
fun CallWiseTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}

package com.callwise.ai.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.callwise.ai.domain.model.CallDirection
import com.callwise.ai.domain.model.CallerCategory
import com.callwise.ai.domain.model.RuleType
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.components.CategoryBadge
import com.callwise.ai.ui.components.DateFormatters
import com.callwise.ai.ui.components.SectionHeader

@Composable
fun IncomingCallProtectionScreen(
    viewModel: CallWiseViewModel,
    onOpenCallerDetails: (Long) -> Unit
) {
    val calls by viewModel.callRecords.collectAsState()
    val simulatedResult by viewModel.simulatedScreeningResult.collectAsState()

    var testNumber by remember { mutableStateOf("") }
    var testName by remember { mutableStateOf("") }
    var testDirection by remember { mutableStateOf(CallDirection.INCOMING) }

    val unknownOrWarnedCalls = remember(calls) {
        calls.filter { !it.isSavedContact }.take(15)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Call Intelligence & Screening",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Advisory-only local analysis for both incoming and outgoing calls. You retain full control in Google Phone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "On-Device Two-Way Classifier Simulator",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CallDirection.entries.forEach { dir ->
                            FilterChip(
                                selected = testDirection == dir,
                                onClick = { testDirection = dir },
                                label = { Text(dir.displayName) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = testNumber,
                        onValueChange = { testNumber = it },
                        label = { Text("Phone number (e.g. +919876543210)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = testName,
                        onValueChange = { testName = it },
                        label = { Text("Optional caller display name (e.g. HDFC Bank)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            viewModel.testLocalScreening(
                                rawNumber = testNumber,
                                callerDisplayName = testName.ifBlank { null },
                                direction = testDirection
                            )
                        },
                        enabled = testNumber.isNotBlank()
                    ) {
                        Text("Test Local Classifier")
                    }

                    simulatedResult?.let { decision ->
                        Spacer(Modifier.height(4.dp))
                        CategoryBadge(category = decision.category)
                        Text(
                            text = decision.recommendation.label,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${decision.direction.displayName} • ${decision.contactTrustStatus.displayName} • ${decision.reason}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        item {
            SectionHeader(title = "Recent Non-Contact Calls")
        }

        if (unknownOrWarnedCalls.isEmpty()) {
            item {
                Text(
                    text = "No unknown callers screened yet.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(unknownOrWarnedCalls, key = { "prot_${it.id}" }) { record ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenCallerDetails(record.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = record.callerName ?: record.rawNumber,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            CategoryBadge(category = record.category)
                        }
                        Text(
                            text = "${record.direction.displayName} • ${record.rawNumber} • ${DateFormatters.formatDateTime(record.timestamp)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = record.screeningReason,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.addOrUpdateRule(
                                        rawNumber = record.rawNumber,
                                        label = record.callerName,
                                        ruleType = RuleType.ALLOWLIST,
                                        category = CallerCategory.PERSONAL_TRUSTED
                                    )
                                }
                            ) {
                                Text("Mark Trusted")
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.addOrUpdateRule(
                                        rawNumber = record.rawNumber,
                                        label = record.callerName,
                                        ruleType = RuleType.BLOCKLIST,
                                        category = CallerCategory.SUSPECTED_SPAM
                                    )
                                }
                            ) {
                                Text("Flag Spam")
                            }
                        }
                    }
                }
            }
        }
    }
}

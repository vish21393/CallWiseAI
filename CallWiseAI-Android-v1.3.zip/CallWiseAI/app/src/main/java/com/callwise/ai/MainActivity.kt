package com.callwise.ai

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.callwise.ai.notifications.CallNotificationManager
import com.callwise.ai.ui.CallWiseNavHost
import com.callwise.ai.ui.CallWiseViewModel
import com.callwise.ai.ui.CallWiseViewModelFactory
import com.callwise.ai.ui.theme.CallWiseTheme

class MainActivity : ComponentActivity() {

    private val viewModel: CallWiseViewModel by viewModels {
        CallWiseViewModelFactory(
            appContext = applicationContext,
            container = (application as CallWiseApplication).container
        )
    }

    private val contactsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.syncContactsNow()
    }

    private val phoneStatePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.registerCallStateMonitor()
    }

    private val voipAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    private val notificationsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    private val screeningRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val initialRecordId = intent?.getLongExtra(CallNotificationManager.EXTRA_CALL_RECORD_ID, -1L)
            ?.takeIf { it > 0L }
        val openDailySummary = intent?.getBooleanExtra(
            CallNotificationManager.EXTRA_OPEN_DAILY_SUMMARY,
            false
        ) ?: false

        setContent {
            CallWiseTheme {
                CallWiseNavHost(
                    viewModel = viewModel,
                    initialRecordId = initialRecordId,
                    openDailySummaryInitially = openDailySummary,
                    onRequestScreeningRole = { requestCallScreeningRole() },
                    onRequestContactsPermission = {
                        contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                    },
                    onRequestPhoneStatePermission = {
                        phoneStatePermissionLauncher.launch(Manifest.permission.READ_PHONE_STATE)
                    },
                    onRequestVoipAudioPermission = {
                        voipAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    onRequestNotificationPermission = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationsPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    onRequestOverlayPermission = { requestOverlayPermission() }
                )
            }
        }
    }

    private fun requestCallScreeningRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
            ) {
                screeningRoleLauncher.launch(roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
    }
}
